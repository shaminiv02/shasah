import { Portal } from "./components/Portal";

export default function App() {
  return <Portal />;
}