import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Progress } from "./ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Alert, AlertDescription } from "./ui/alert";
import { 
  Users, 
  AlertTriangle, 
  TrendingUp, 
  TrendingDown, 
  Gift, 
  MessageSquare, 
  Calendar, 
  Target,
  Award,
  Zap,
  CheckCircle,
  Clock,
  Star,
  Trophy,
  BarChart3
} from "lucide-react";

interface Mentee {
  id: string;
  name: string;
  avatar?: string;
  level: number;
  totalPoints: number;
  riskScore: number;
  riskLevel: 'Low' | 'Medium' | 'High' | 'Critical';
  gpa: number;
  attendance: number;
  participationScore: number;
  lastActivity: string;
  currentStreak: number;
  recentTrend: 'up' | 'down' | 'stable';
  flaggedAlerts: number;
  completedChallenges: number;
  activeChallenges: number;
}

interface GroupAnalytics {
  totalMentees: number;
  averageRiskScore: number;
  highRiskCount: number;
  averageGPA: number;
  averageAttendance: number;
  totalPointsAwarded: number;
  challengesCompleted: number;
  improvementRate: number;
}

interface MentorDashboardProps {
  mentorData: {
    name: string;
    id: string;
    avatar?: string;
    mentees: Mentee[];
    analytics: GroupAnalytics;
    pendingActions: Array<{
      id: string;
      type: 'review' | 'reward' | 'intervention' | 'checkin';
      menteeId: string;
      menteeName: string;
      description: string;
      priority: 'low' | 'medium' | 'high';
      timestamp: string;
    }>;
  };
}

export function MentorDashboard({ mentorData }: MentorDashboardProps) {
  const [selectedTab, setSelectedTab] = useState('overview');
  const [selectedMentee, setSelectedMentee] = useState<Mentee | null>(null);

  const { name, id, avatar, mentees, analytics, pendingActions } = mentorData;

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'Low': return 'bg-green-100 text-green-800 border-green-200';
      case 'Medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'High': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Critical': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="h-4 w-4 text-green-600" />;
      case 'down': return <TrendingDown className="h-4 w-4 text-red-600" />;
      default: return <div className="h-4 w-4 bg-gray-400 rounded-full" />;
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-blue-100 text-blue-800 border-blue-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getActionIcon = (type: string) => {
    switch (type) {
      case 'review': return <CheckCircle className="h-4 w-4" />;
      case 'reward': return <Gift className="h-4 w-4" />;
      case 'intervention': return <AlertTriangle className="h-4 w-4" />;
      case 'checkin': return <MessageSquare className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const highRiskMentees = mentees.filter(m => m.riskLevel === 'High' || m.riskLevel === 'Critical');
  const criticalActions = pendingActions.filter(a => a.priority === 'high');

  return (
    <div className="space-y-6">
      {/* Header */}
      <Card className="bg-gradient-to-r from-purple-500 to-indigo-600 text-white border-0">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Avatar className="h-16 w-16 border-4 border-white/20">
                <AvatarImage src={avatar} />
                <AvatarFallback className="text-purple-600 text-lg font-semibold">
                  {name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <div>
                <h1 className="text-2xl font-bold">{name}</h1>
                <p className="text-purple-100">Mentor ID: {id}</p>
                <div className="flex items-center space-x-4 mt-2">
                  <div className="flex items-center space-x-1">
                    <Users className="h-4 w-4" />
                    <span>{analytics.totalMentees} Mentees</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Trophy className="h-4 w-4 text-yellow-300" />
                    <span>{analytics.challengesCompleted} Challenges Completed</span>
                  </div>
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold">{analytics.totalPointsAwarded}</div>
              <div className="text-purple-100">Points Awarded</div>
              {criticalActions.length > 0 && (
                <Badge variant="destructive" className="mt-2">
                  {criticalActions.length} Urgent Action{criticalActions.length !== 1 ? 's' : ''}
                </Badge>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Critical Alerts */}
      {highRiskMentees.length > 0 && (
        <Alert className="border-red-200 bg-red-50">
          <AlertTriangle className="h-4 w-4 text-red-600" />
          <AlertDescription className="text-red-800">
            <strong>{highRiskMentees.length} student{highRiskMentees.length !== 1 ? 's' : ''} flagged as high risk:</strong>{' '}
            {highRiskMentees.map(m => m.name).join(', ')}. Immediate attention recommended.
          </AlertDescription>
        </Alert>
      )}

      <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="mentees">Mentees</TabsTrigger>
          <TabsTrigger value="actions">Actions</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
              <div className="text-2xl font-bold text-blue-700">{analytics.averageGPA.toFixed(1)}</div>
              <div className="text-sm text-blue-600">Avg GPA</div>
            </Card>
            <Card className="text-center p-4 bg-gradient-to-br from-green-50 to-green-100 border-green-200">
              <div className="text-2xl font-bold text-green-700">{analytics.averageAttendance}%</div>
              <div className="text-sm text-green-600">Avg Attendance</div>
            </Card>
            <Card className="text-center p-4 bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
              <div className="text-2xl font-bold text-purple-700">{analytics.challengesCompleted}</div>
              <div className="text-sm text-purple-600">Challenges Done</div>
            </Card>
            <Card className="text-center p-4 bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
              <div className="text-2xl font-bold text-orange-700">+{analytics.improvementRate}%</div>
              <div className="text-sm text-orange-600">Improvement</div>
            </Card>
          </div>

          {/* Recent Mentee Activity */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Star className="h-5 w-5 text-yellow-600" />
                  <span>Top Performers</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {mentees
                  .sort((a, b) => b.totalPoints - a.totalPoints)
                  .slice(0, 3)
                  .map((mentee, index) => (
                  <div key={mentee.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <div className="flex items-center justify-center w-6 h-6 rounded-full bg-yellow-100 text-yellow-800 text-sm font-bold">
                        {index + 1}
                      </div>
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={mentee.avatar} />
                        <AvatarFallback className="text-xs">
                          {mentee.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium text-sm">{mentee.name}</p>
                        <p className="text-xs text-muted-foreground">Level {mentee.level}</p>
                      </div>
                    </div>
                    <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                      {mentee.totalPoints} pts
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <AlertTriangle className="h-5 w-5 text-red-600" />
                  <span>Needs Attention</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                {mentees
                  .filter(m => m.riskLevel === 'High' || m.riskLevel === 'Critical' || m.flaggedAlerts > 0)
                  .slice(0, 3)
                  .map((mentee) => (
                  <div key={mentee.id} className="flex items-center justify-between p-3 bg-red-50 border border-red-200 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-8 w-8">
                        <AvatarImage src={mentee.avatar} />
                        <AvatarFallback className="text-xs">
                          {mentee.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium text-sm">{mentee.name}</p>
                        <p className="text-xs text-red-600">{mentee.flaggedAlerts} alert{mentee.flaggedAlerts !== 1 ? 's' : ''}</p>
                      </div>
                    </div>
                    <Badge variant="outline" className={getRiskColor(mentee.riskLevel)}>
                      {mentee.riskLevel}
                    </Badge>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="mentees" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {mentees.map((mentee) => (
              <Card 
                key={mentee.id} 
                className={`cursor-pointer transition-all hover:shadow-lg ${
                  selectedMentee?.id === mentee.id ? 'ring-2 ring-purple-500' : ''
                }`}
                onClick={() => setSelectedMentee(mentee)}
              >
                <CardContent className="p-4">
                  <div className="flex items-center justify-between mb-3">
                    <div className="flex items-center space-x-3">
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={mentee.avatar} />
                        <AvatarFallback>
                          {mentee.name.split(' ').map(n => n[0]).join('')}
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-semibold">{mentee.name}</h3>
                        <p className="text-sm text-muted-foreground">Level {mentee.level}</p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-2">
                      {getTrendIcon(mentee.recentTrend)}
                      <Badge variant="outline" className={getRiskColor(mentee.riskLevel)}>
                        {mentee.riskScore}%
                      </Badge>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>GPA:</span>
                      <span className="font-medium">{mentee.gpa.toFixed(1)}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Attendance:</span>
                      <span className="font-medium">{mentee.attendance}%</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Participation:</span>
                      <span className="font-medium">{mentee.participationScore}%</span>
                    </div>
                  </div>

                  <div className="flex justify-between items-center mt-3 pt-3 border-t">
                    <div className="text-xs text-muted-foreground">
                      {mentee.currentStreak} day streak
                    </div>
                    <div className="flex space-x-1">
                      <Button size="sm" variant="outline" className="h-7 px-2">
                        <Gift className="h-3 w-3" />
                      </Button>
                      <Button size="sm" variant="outline" className="h-7 px-2">
                        <MessageSquare className="h-3 w-3" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="actions" className="space-y-6">
          {/* Action Tools */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="p-4">
              <Button className="w-full justify-start bg-gradient-to-r from-green-500 to-green-600">
                <Gift className="h-4 w-4 mr-2" />
                Award Points/Badge
              </Button>
            </Card>
            <Card className="p-4">
              <Button className="w-full justify-start bg-gradient-to-r from-blue-500 to-blue-600">
                <Target className="h-4 w-4 mr-2" />
                Create Challenge
              </Button>
            </Card>
            <Card className="p-4">
              <Button className="w-full justify-start bg-gradient-to-r from-purple-500 to-purple-600">
                <Calendar className="h-4 w-4 mr-2" />
                Schedule Check-in
              </Button>
            </Card>
          </div>

          {/* Pending Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Pending Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {pendingActions.map((action) => (
                <div key={action.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center space-x-3">
                    <div className={`p-2 rounded-full ${getPriorityColor(action.priority)}`}>
                      {getActionIcon(action.type)}
                    </div>
                    <div>
                      <p className="font-medium">{action.description}</p>
                      <p className="text-sm text-muted-foreground">
                        {action.menteeName} • {action.timestamp}
                      </p>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button size="sm" variant="outline">
                      View
                    </Button>
                    <Button size="sm">
                      Complete
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          {/* Analytics Overview */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <BarChart3 className="h-5 w-5" />
                  <span>Group Performance</span>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Average Risk Score</span>
                      <span className="text-sm font-medium">{analytics.averageRiskScore}%</span>
                    </div>
                    <Progress value={analytics.averageRiskScore} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Group GPA</span>
                      <span className="text-sm font-medium">{analytics.averageGPA.toFixed(1)}/4.0</span>
                    </div>
                    <Progress value={(analytics.averageGPA / 4.0) * 100} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-1">
                      <span className="text-sm">Average Attendance</span>
                      <span className="text-sm font-medium">{analytics.averageAttendance}%</span>
                    </div>
                    <Progress value={analytics.averageAttendance} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Award className="h-5 w-5" />
                  <span>Intervention Impact</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center space-y-3">
                  <div className="text-4xl font-bold text-green-600">+{analytics.improvementRate}%</div>
                  <p className="text-sm text-muted-foreground">Average improvement in risk scores</p>
                  <div className="grid grid-cols-2 gap-4 mt-4">
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <div className="text-lg font-bold text-green-700">{analytics.challengesCompleted}</div>
                      <div className="text-xs text-green-600">Challenges Completed</div>
                    </div>
                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <div className="text-lg font-bold text-blue-700">{analytics.totalPointsAwarded}</div>
                      <div className="text-xs text-blue-600">Points Awarded</div>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}