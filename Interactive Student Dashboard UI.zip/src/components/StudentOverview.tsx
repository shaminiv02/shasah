import { useState } from "react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "./ui/table";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Progress } from "./ui/progress";
import { Eye, AlertTriangle, CheckCircle, XCircle } from "lucide-react";

interface Student {
  id: string;
  name: string;
  grade: string;
  gpa: number;
  attendance: number;
  assignmentCompletion: number;
  participationScore: number;
  riskScore: number;
  riskLevel: 'Low' | 'Medium' | 'High' | 'Critical';
  lastActivity: string;
  enrollmentStatus: 'Active' | 'Inactive' | 'Probation';
}

interface StudentOverviewProps {
  students: Student[];
  onStudentSelect: (student: Student) => void;
  selectedStudent?: Student;
}

export function StudentOverview({ students, onStudentSelect, selectedStudent }: StudentOverviewProps) {
  const getRiskColor = (level: string) => {
    switch (level) {
      case 'Low': return 'bg-green-100 text-green-800 border-green-200';
      case 'Medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'High': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Critical': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'Active': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'Probation': return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      case 'Inactive': return <XCircle className="h-4 w-4 text-red-600" />;
      default: return null;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Student Overview</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="rounded-md border">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Student</TableHead>
                <TableHead>Grade</TableHead>
                <TableHead>GPA</TableHead>
                <TableHead>Attendance</TableHead>
                <TableHead>Assignments</TableHead>
                <TableHead>Participation</TableHead>
                <TableHead>Risk Level</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {students.map((student) => (
                <TableRow 
                  key={student.id}
                  className={`cursor-pointer hover:bg-muted/50 ${
                    selectedStudent?.id === student.id ? 'bg-muted' : ''
                  }`}
                  onClick={() => onStudentSelect(student)}
                >
                  <TableCell>
                    <div>
                      <div className="font-medium">{student.name}</div>
                      <div className="text-sm text-muted-foreground">ID: {student.id}</div>
                    </div>
                  </TableCell>
                  <TableCell>{student.grade}</TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <span>{student.gpa.toFixed(2)}</span>
                      <Progress value={(student.gpa / 4.0) * 100} className="w-16 h-2" />
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <span>{student.attendance}%</span>
                      <Progress value={student.attendance} className="w-16 h-2" />
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <span>{student.assignmentCompletion}%</span>
                      <Progress value={student.assignmentCompletion} className="w-16 h-2" />
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      <span>{student.participationScore}%</span>
                      <Progress value={student.participationScore} className="w-16 h-2" />
                    </div>
                  </TableCell>
                  <TableCell>
                    <Badge variant="outline" className={getRiskColor(student.riskLevel)}>
                      {student.riskLevel} ({student.riskScore}%)
                    </Badge>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center space-x-2">
                      {getStatusIcon(student.enrollmentStatus)}
                      <span className="text-sm">{student.enrollmentStatus}</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <Button 
                      variant="ghost" 
                      size="sm"
                      onClick={(e) => {
                        e.stopPropagation();
                        onStudentSelect(student);
                      }}
                    >
                      <Eye className="h-4 w-4" />
                    </Button>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}