import { useState, useEffect } from "react";
import { Sidebar, SidebarContent, SidebarHeader, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarProvider, SidebarTrigger } from "./ui/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { 
  Users, 
  TrendingUp, 
  AlertTriangle, 
  MessageSquare, 
  Upload, 
  BarChart3,
  GraduationCap,
  Bell,
  Settings,
  Home
} from "lucide-react";

import { StudentOverview } from "./StudentOverview";
import { TimeSeriesVisualization } from "./TimeSeriesVisualization";
import { DropoutRiskIndicator } from "./DropoutRiskIndicator";
import { TextInteractionInsight } from "./TextInteractionInsight";
import { FiltersAndSearch } from "./FiltersAndSearch";
import { CounselorAlerts } from "./CounselorAlerts";
import { DataUploadSync } from "./DataUploadSync";

// Mock data
const mockStudents = [
  {
    id: "ST001",
    name: "Emily Rodriguez",
    grade: "11th Grade",
    gpa: 3.8,
    attendance: 95,
    assignmentCompletion: 92,
    participationScore: 88,
    riskScore: 15,
    riskLevel: "Low" as const,
    lastActivity: "2024-03-15",
    enrollmentStatus: "Active" as const,
    riskFactors: [
      { name: "Academic Performance", value: 85, impact: "positive" as const, description: "Consistently high grades across subjects" },
      { name: "Attendance Rate", value: 95, impact: "positive" as const, description: "Excellent attendance record" }
    ],
    previousRiskScore: 18
  },
  {
    id: "ST002", 
    name: "Marcus Johnson",
    grade: "10th Grade",
    gpa: 2.1,
    attendance: 72,
    assignmentCompletion: 65,
    participationScore: 45,
    riskScore: 78,
    riskLevel: "High" as const,
    lastActivity: "2024-03-14",
    enrollmentStatus: "Probation" as const,
    riskFactors: [
      { name: "Low GPA", value: 70, impact: "negative" as const, description: "GPA below 2.5 threshold" },
      { name: "Poor Attendance", value: 60, impact: "negative" as const, description: "Missing 28% of classes" },
      { name: "Assignment Completion", value: 55, impact: "negative" as const, description: "Only 65% assignments completed" }
    ],
    previousRiskScore: 65
  },
  {
    id: "ST003",
    name: "Sarah Chen",
    grade: "12th Grade", 
    gpa: 3.2,
    attendance: 88,
    assignmentCompletion: 85,
    participationScore: 92,
    riskScore: 35,
    riskLevel: "Medium" as const,
    lastActivity: "2024-03-15",
    enrollmentStatus: "Active" as const,
    riskFactors: [
      { name: "Academic Stress", value: 40, impact: "negative" as const, description: "Recent decline in performance during senior year" },
      { name: "Good Participation", value: 85, impact: "positive" as const, description: "Active class participation" }
    ]
  }
];

const mockTimeSeriesData = [
  { month: "Sep", grade: 3.8, attendance: 95, participation: 88, assignments: 92, riskScore: 15 },
  { month: "Oct", grade: 3.7, attendance: 93, participation: 85, assignments: 90, riskScore: 18 },
  { month: "Nov", grade: 3.9, attendance: 96, participation: 90, assignments: 94, riskScore: 12 },
  { month: "Dec", grade: 3.8, attendance: 94, participation: 87, assignments: 91, riskScore: 16 },
  { month: "Jan", grade: 3.6, attendance: 92, participation: 82, assignments: 88, riskScore: 22 },
  { month: "Feb", grade: 3.8, attendance: 95, participation: 89, assignments: 93, riskScore: 15 },
];

const mockInteractions = [
  {
    id: "1",
    date: "2024-03-14",
    type: "email" as const,
    content: "I'm really struggling with calculus this semester. The concepts are getting harder and I don't understand the homework.",
    sentiment: {
      emotion: "concerned" as const,
      confidence: 85,
      keywords: ["struggling", "harder", "don't understand"]
    },
    flagged: true
  },
  {
    id: "2", 
    date: "2024-03-13",
    type: "chat" as const,
    content: "Thanks for the extra help session! I feel much better about the upcoming test now.",
    sentiment: {
      emotion: "positive" as const,
      confidence: 92,
      keywords: ["thanks", "better", "help"]
    },
    flagged: false
  }
];

const mockAlerts = [
  {
    id: "A001",
    studentId: "ST002",
    studentName: "Marcus Johnson",
    type: "risk_increase" as const,
    severity: "critical" as const,
    title: "Dropout Risk Increased to 78%",
    description: "Student's risk score has increased by 13 points in the last two weeks due to declining attendance and missed assignments.",
    recommendation: "Schedule immediate one-on-one counseling session. Contact parents/guardians. Consider academic intervention plan.",
    timestamp: "2024-03-15T10:30:00Z",
    isRead: false,
    isActionTaken: false
  },
  {
    id: "A002",
    studentId: "ST003", 
    studentName: "Sarah Chen",
    type: "attendance_drop" as const,
    severity: "medium" as const,
    title: "Attendance Below Threshold",
    description: "Student attendance has dropped to 88% over the past month, down from previous 95% average.",
    recommendation: "Check in with student about potential barriers to attendance. Offer flexible scheduling if needed.",
    timestamp: "2024-03-15T09:15:00Z",
    isRead: true,
    isActionTaken: false
  }
];

interface DashboardProps {}

export function Dashboard({}: DashboardProps) {
  const [activeView, setActiveView] = useState("overview");
  const [selectedStudent, setSelectedStudent] = useState(mockStudents[0]);
  const [filteredStudents, setFilteredStudents] = useState(mockStudents);
  const [alerts, setAlerts] = useState(mockAlerts);

  const handleFiltersChange = (filters: any) => {
    // Implement filtering logic here
    let filtered = mockStudents;
    
    if (filters.search) {
      filtered = filtered.filter(student => 
        student.name.toLowerCase().includes(filters.search.toLowerCase()) ||
        student.id.toLowerCase().includes(filters.search.toLowerCase())
      );
    }
    
    if (filters.riskLevel) {
      filtered = filtered.filter(student => student.riskLevel === filters.riskLevel);
    }
    
    if (filters.enrollmentStatus) {
      filtered = filtered.filter(student => student.enrollmentStatus === filters.enrollmentStatus);
    }
    
    if (filters.grade) {
      filtered = filtered.filter(student => student.grade === filters.grade);
    }
    
    setFilteredStudents(filtered);
  };

  const handleMarkAsRead = (alertId: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === alertId ? { ...alert, isRead: true } : alert
    ));
  };

  const handleMarkActionTaken = (alertId: string) => {
    setAlerts(prev => prev.map(alert => 
      alert.id === alertId ? { ...alert, isActionTaken: true } : alert
    ));
  };

  const handleDismissAlert = (alertId: string) => {
    setAlerts(prev => prev.filter(alert => alert.id !== alertId));
  };

  const sidebarItems = [
    { id: "overview", label: "Overview", icon: Home },
    { id: "students", label: "Students", icon: Users },
    { id: "analytics", label: "Analytics", icon: BarChart3 },
    { id: "alerts", label: "Alerts", icon: Bell },
    { id: "insights", label: "Text Insights", icon: MessageSquare },
    { id: "upload", label: "Data Upload", icon: Upload },
    { id: "settings", label: "Settings", icon: Settings }
  ];

  const unreadAlerts = alerts.filter(alert => !alert.isRead).length;
  const criticalAlerts = alerts.filter(alert => alert.severity === 'critical').length;

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full">
        <Sidebar>
          <SidebarHeader className="border-b p-4">
            <div className="flex items-center space-x-2">
              <GraduationCap className="h-6 w-6 text-primary" />
              <span className="font-semibold">Dropout Prediction System</span>
            </div>
          </SidebarHeader>
          <SidebarContent>
            <SidebarMenu>
              {sidebarItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton 
                    onClick={() => setActiveView(item.id)}
                    isActive={activeView === item.id}
                    className="w-full"
                  >
                    <item.icon className="h-4 w-4" />
                    <span>{item.label}</span>
                    {item.id === "alerts" && unreadAlerts > 0 && (
                      <Badge variant="destructive" className="ml-auto text-xs">
                        {unreadAlerts}
                      </Badge>
                    )}
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarContent>
        </Sidebar>

        <main className="flex-1 p-6 space-y-6 overflow-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <SidebarTrigger />
              <h1 className="text-2xl font-semibold">
                {sidebarItems.find(item => item.id === activeView)?.label || "Dashboard"}
              </h1>
            </div>
            {criticalAlerts > 0 && (
              <Badge variant="destructive" className="flex items-center space-x-1">
                <AlertTriangle className="h-3 w-3" />
                <span>{criticalAlerts} Critical Alert{criticalAlerts !== 1 ? 's' : ''}</span>
              </Badge>
            )}
          </div>

          {activeView === "overview" && (
            <div className="grid grid-cols-1 xl:grid-cols-4 gap-6">
              <div className="xl:col-span-2">
                <Card className="mb-6">
                  <CardHeader>
                    <CardTitle>System Overview</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                      <div className="text-center p-3 bg-blue-50 rounded border border-blue-200">
                        <Users className="h-6 w-6 mx-auto mb-2 text-blue-600" />
                        <div className="text-2xl font-bold text-blue-800">{mockStudents.length}</div>
                        <div className="text-sm text-blue-600">Total Students</div>
                      </div>
                      <div className="text-center p-3 bg-red-50 rounded border border-red-200">
                        <AlertTriangle className="h-6 w-6 mx-auto mb-2 text-red-600" />
                        <div className="text-2xl font-bold text-red-800">{mockStudents.filter(s => s.riskLevel === 'Critical' || s.riskLevel === 'High').length}</div>
                        <div className="text-sm text-red-600">High Risk</div>
                      </div>
                      <div className="text-center p-3 bg-yellow-50 rounded border border-yellow-200">
                        <TrendingUp className="h-6 w-6 mx-auto mb-2 text-yellow-600" />
                        <div className="text-2xl font-bold text-yellow-800">{mockStudents.filter(s => s.riskLevel === 'Medium').length}</div>
                        <div className="text-sm text-yellow-600">Medium Risk</div>
                      </div>
                      <div className="text-center p-3 bg-green-50 rounded border border-green-200">
                        <Users className="h-6 w-6 mx-auto mb-2 text-green-600" />
                        <div className="text-2xl font-bold text-green-800">{mockStudents.filter(s => s.riskLevel === 'Low').length}</div>
                        <div className="text-sm text-green-600">Low Risk</div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <StudentOverview 
                  students={filteredStudents}
                  onStudentSelect={setSelectedStudent}
                  selectedStudent={selectedStudent}
                />
              </div>
              <div className="xl:col-span-2 space-y-6">
                <DropoutRiskIndicator student={selectedStudent} />
                <CounselorAlerts 
                  alerts={alerts}
                  onMarkAsRead={handleMarkAsRead}
                  onMarkActionTaken={handleMarkActionTaken}
                  onDismissAlert={handleDismissAlert}
                />
              </div>
            </div>
          )}

          {activeView === "students" && (
            <div className="space-y-6">
              <FiltersAndSearch 
                onFiltersChange={handleFiltersChange}
                totalStudents={mockStudents.length}
                filteredStudents={filteredStudents.length}
              />
              <StudentOverview 
                students={filteredStudents}
                onStudentSelect={setSelectedStudent}
                selectedStudent={selectedStudent}
              />
            </div>
          )}

          {activeView === "analytics" && (
            <div className="space-y-6">
              <TimeSeriesVisualization 
                data={mockTimeSeriesData}
                studentName={selectedStudent?.name}
              />
              <DropoutRiskIndicator student={selectedStudent} />
            </div>
          )}

          {activeView === "alerts" && (
            <CounselorAlerts 
              alerts={alerts}
              onMarkAsRead={handleMarkAsRead}
              onMarkActionTaken={handleMarkActionTaken}
              onDismissAlert={handleDismissAlert}
            />
          )}

          {activeView === "insights" && (
            <TextInteractionInsight 
              interactions={mockInteractions}
              studentName={selectedStudent?.name || "Selected Student"}
            />
          )}

          {activeView === "upload" && (
            <DataUploadSync />
          )}

          {activeView === "settings" && (
            <Card>
              <CardHeader>
                <CardTitle>System Settings</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-muted-foreground">Settings configuration would be implemented here.</p>
              </CardContent>
            </Card>
          )}
        </main>
      </div>
    </SidebarProvider>
  );
}