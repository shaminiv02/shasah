import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { 
  Trophy, 
  Star, 
  Target, 
  TrendingUp, 
  Calendar, 
  BookOpen, 
  Users, 
  MessageCircle,
  Gift,
  Zap,
  Award,
  Crown,
  Flame
} from "lucide-react";

interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  earned: boolean;
  progress?: number;
  maxProgress?: number;
  points: number;
}

interface StudentStats {
  totalPoints: number;
  level: number;
  currentStreak: number;
  gpa: number;
  attendance: number;
  assignmentsCompleted: number;
  totalAssignments: number;
  participationScore: number;
  riskLevel: 'Low' | 'Medium' | 'High';
  motivationalMessage: string;
  nextLevelPoints: number;
  currentLevelPoints: number;
}

interface StudentDashboardProps {
  studentData: {
    name: string;
    id: string;
    avatar?: string;
    stats: StudentStats;
    achievements: Achievement[];
    recentActivities: Array<{
      id: string;
      type: 'assignment' | 'attendance' | 'participation' | 'achievement';
      description: string;
      points: number;
      timestamp: string;
    }>;
  };
}

export function StudentDashboard({ studentData }: StudentDashboardProps) {
  const [selectedTab, setSelectedTab] = useState('overview');

  const { name, id, avatar, stats, achievements, recentActivities } = studentData;

  const levelProgress = ((stats.totalPoints - stats.currentLevelPoints) / (stats.nextLevelPoints - stats.currentLevelPoints)) * 100;

  const getRiskColor = (level: string) => {
    switch (level) {
      case 'Low': return 'bg-green-100 text-green-800 border-green-200';
      case 'Medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'High': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'assignment': return <BookOpen className="h-4 w-4 text-blue-600" />;
      case 'attendance': return <Calendar className="h-4 w-4 text-green-600" />;
      case 'participation': return <Users className="h-4 w-4 text-purple-600" />;
      case 'achievement': return <Award className="h-4 w-4 text-yellow-600" />;
      default: return <Zap className="h-4 w-4 text-gray-600" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header with Profile and Level */}
      <Card className="bg-gradient-to-r from-blue-500 to-purple-600 text-white border-0">
        <CardContent className="p-6">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Avatar className="h-16 w-16 border-4 border-white/20">
                <AvatarImage src={avatar} />
                <AvatarFallback className="text-blue-600 text-lg font-semibold">
                  {name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              <div>
                <h1 className="text-2xl font-bold">{name}</h1>
                <p className="text-blue-100">Student ID: {id}</p>
                <div className="flex items-center space-x-2 mt-2">
                  <Crown className="h-5 w-5 text-yellow-300" />
                  <span className="text-lg font-semibold">Level {stats.level}</span>
                </div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold">{stats.totalPoints}</div>
              <div className="text-blue-100">Total Points</div>
              <div className="flex items-center space-x-2 mt-2">
                <Flame className="h-4 w-4 text-orange-300" />
                <span>{stats.currentStreak} day streak</span>
              </div>
            </div>
          </div>
          
          {/* Level Progress */}
          <div className="mt-4">
            <div className="flex justify-between text-sm mb-2">
              <span>Level {stats.level}</span>
              <span>{stats.nextLevelPoints - stats.totalPoints} points to next level</span>
            </div>
            <div className="bg-white/20 rounded-full h-3">
              <div 
                className="bg-gradient-to-r from-yellow-300 to-orange-300 h-3 rounded-full transition-all duration-300"
                style={{ width: `${levelProgress}%` }}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Academic Progress */}
        <div className="lg:col-span-2 space-y-6">
          {/* Quick Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card className="text-center p-4 bg-gradient-to-br from-green-50 to-green-100 border-green-200">
              <div className="text-2xl font-bold text-green-700">{stats.gpa.toFixed(1)}</div>
              <div className="text-sm text-green-600">GPA</div>
              <Progress value={(stats.gpa / 4.0) * 100} className="mt-2 h-2" />
            </Card>
            <Card className="text-center p-4 bg-gradient-to-br from-blue-50 to-blue-100 border-blue-200">
              <div className="text-2xl font-bold text-blue-700">{stats.attendance}%</div>
              <div className="text-sm text-blue-600">Attendance</div>
              <Progress value={stats.attendance} className="mt-2 h-2" />
            </Card>
            <Card className="text-center p-4 bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
              <div className="text-2xl font-bold text-purple-700">{stats.assignmentsCompleted}/{stats.totalAssignments}</div>
              <div className="text-sm text-purple-600">Assignments</div>
              <Progress value={(stats.assignmentsCompleted / stats.totalAssignments) * 100} className="mt-2 h-2" />
            </Card>
            <Card className="text-center p-4 bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
              <div className="text-2xl font-bold text-orange-700">{stats.participationScore}%</div>
              <div className="text-sm text-orange-600">Participation</div>
              <Progress value={stats.participationScore} className="mt-2 h-2" />
            </Card>
          </div>

          {/* Motivational Message */}
          <Card className="bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-200">
            <CardContent className="p-6">
              <div className="flex items-start space-x-3">
                <div className="p-2 bg-emerald-100 rounded-full">
                  <Target className="h-5 w-5 text-emerald-600" />
                </div>
                <div>
                  <h3 className="font-semibold text-emerald-800">Your Personalized Tip</h3>
                  <p className="text-emerald-700 mt-1">{stats.motivationalMessage}</p>
                  <Badge variant="outline" className={`mt-2 ${getRiskColor(stats.riskLevel)}`}>
                    Risk Level: {stats.riskLevel}
                  </Badge>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recent Activities */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <TrendingUp className="h-5 w-5" />
                <span>Recent Activity</span>
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recentActivities.slice(0, 5).map((activity) => (
                  <div key={activity.id} className="flex items-center justify-between p-3 bg-muted/50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      {getActivityIcon(activity.type)}
                      <div>
                        <p className="font-medium text-sm">{activity.description}</p>
                        <p className="text-xs text-muted-foreground">{activity.timestamp}</p>
                      </div>
                    </div>
                    <Badge variant="secondary" className="bg-green-100 text-green-800">
                      +{activity.points} pts
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Gamification Panel */}
        <div className="space-y-6">
          {/* Achievements */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Trophy className="h-5 w-5 text-yellow-600" />
                <span>Achievements</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {achievements.slice(0, 4).map((achievement) => (
                <div 
                  key={achievement.id} 
                  className={`p-3 rounded-lg border ${
                    achievement.earned 
                      ? 'bg-yellow-50 border-yellow-200' 
                      : 'bg-gray-50 border-gray-200'
                  }`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      <div className={`text-lg ${achievement.earned ? 'grayscale-0' : 'grayscale'}`}>
                        {achievement.icon}
                      </div>
                      <span className={`font-medium text-sm ${
                        achievement.earned ? 'text-yellow-800' : 'text-gray-600'
                      }`}>
                        {achievement.title}
                      </span>
                    </div>
                    <Badge variant={achievement.earned ? "default" : "secondary"} className="text-xs">
                      {achievement.points} pts
                    </Badge>
                  </div>
                  <p className={`text-xs ${
                    achievement.earned ? 'text-yellow-700' : 'text-gray-500'
                  }`}>
                    {achievement.description}
                  </p>
                  {!achievement.earned && achievement.progress && achievement.maxProgress && (
                    <div className="mt-2">
                      <Progress 
                        value={(achievement.progress / achievement.maxProgress) * 100} 
                        className="h-1"
                      />
                      <div className="text-xs text-gray-500 mt-1">
                        {achievement.progress} / {achievement.maxProgress}
                      </div>
                    </div>
                  )}
                </div>
              ))}
              <Button variant="outline" className="w-full">
                View All Achievements
              </Button>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Zap className="h-5 w-5 text-blue-600" />
                <span>Quick Actions</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <Button className="w-full justify-start bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700">
                <MessageCircle className="h-4 w-4 mr-2" />
                Chat with AI Counselor
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Gift className="h-4 w-4 mr-2" />
                Redeem Rewards
              </Button>
              <Button variant="outline" className="w-full justify-start">
                <Star className="h-4 w-4 mr-2" />
                View Leaderboard
              </Button>
            </CardContent>
          </Card>

          {/* Current Challenges */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center space-x-2">
                <Target className="h-5 w-5 text-purple-600" />
                <span>Active Challenges</span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="p-3 bg-purple-50 border border-purple-200 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-sm text-purple-800">Perfect Week</span>
                  <Badge variant="secondary" className="bg-purple-100 text-purple-800">50 pts</Badge>
                </div>
                <p className="text-xs text-purple-700">Attend all classes this week</p>
                <Progress value={85} className="mt-2 h-2" />
                <div className="text-xs text-purple-600 mt-1">4 / 5 days complete</div>
              </div>
              
              <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <span className="font-medium text-sm text-green-800">Assignment Master</span>
                  <Badge variant="secondary" className="bg-green-100 text-green-800">30 pts</Badge>
                </div>
                <p className="text-xs text-green-700">Submit 3 assignments on time</p>
                <Progress value={67} className="mt-2 h-2" />
                <div className="text-xs text-green-600 mt-1">2 / 3 assignments done</div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}