import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { ScrollArea } from "./ui/scroll-area";
import { MessageCircle, Heart, Frown, Meh, Smile, AlertTriangle } from "lucide-react";

interface SentimentData {
  emotion: 'positive' | 'negative' | 'neutral' | 'concerned' | 'frustrated';
  confidence: number;
  keywords: string[];
}

interface TextInteraction {
  id: string;
  date: string;
  type: 'email' | 'chat' | 'forum' | 'feedback';
  content: string;
  sentiment: SentimentData;
  flagged: boolean;
}

interface TextInteractionInsightProps {
  interactions: TextInteraction[];
  studentName: string;
}

export function TextInteractionInsight({ interactions, studentName }: TextInteractionInsightProps) {
  const getSentimentIcon = (emotion: string) => {
    switch (emotion) {
      case 'positive': return <Smile className="h-4 w-4 text-green-600" />;
      case 'negative': return <Frown className="h-4 w-4 text-red-600" />;
      case 'neutral': return <Meh className="h-4 w-4 text-gray-600" />;
      case 'concerned': return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      case 'frustrated': return <Frown className="h-4 w-4 text-orange-600" />;
      default: return <Meh className="h-4 w-4 text-gray-600" />;
    }
  };

  const getSentimentColor = (emotion: string) => {
    switch (emotion) {
      case 'positive': return 'bg-green-100 text-green-800 border-green-200';
      case 'negative': return 'bg-red-100 text-red-800 border-red-200';
      case 'neutral': return 'bg-gray-100 text-gray-800 border-gray-200';
      case 'concerned': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'frustrated': return 'bg-orange-100 text-orange-800 border-orange-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'email': return '📧';
      case 'chat': return '💬';
      case 'forum': return '🗣️';
      case 'feedback': return '📝';
      default: return '💬';
    }
  };

  // Calculate sentiment summary
  const sentimentSummary = interactions.reduce((acc, interaction) => {
    acc[interaction.sentiment.emotion] = (acc[interaction.sentiment.emotion] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const flaggedInteractions = interactions.filter(i => i.flagged);
  const recentInteractions = interactions.slice(0, 5);

  // Extract all keywords and their frequency
  const allKeywords = interactions.flatMap(i => i.sentiment.keywords);
  const keywordFrequency = allKeywords.reduce((acc, keyword) => {
    acc[keyword] = (acc[keyword] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  const topKeywords = Object.entries(keywordFrequency)
    .sort(([, a], [, b]) => b - a)
    .slice(0, 10);

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <MessageCircle className="h-5 w-5" />
          <span>Text Interaction Analysis - {studentName}</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="recent">Recent Messages</TabsTrigger>
            <TabsTrigger value="flagged">Flagged Content</TabsTrigger>
            <TabsTrigger value="keywords">Keywords</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            {/* Sentiment Summary */}
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
              {Object.entries(sentimentSummary).map(([emotion, count]) => (
                <div key={emotion} className="text-center p-3 bg-muted/50 rounded-lg">
                  <div className="flex justify-center mb-2">
                    {getSentimentIcon(emotion)}
                  </div>
                  <div className="text-sm font-medium capitalize">{emotion}</div>
                  <div className="text-lg font-bold">{count}</div>
                </div>
              ))}
            </div>

            {/* Overall Analysis */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                <h4 className="font-medium text-blue-800 mb-2">Total Interactions</h4>
                <p className="text-2xl font-bold text-blue-900">{interactions.length}</p>
              </div>
              <div className="p-4 bg-red-50 border border-red-200 rounded-lg">
                <h4 className="font-medium text-red-800 mb-2">Flagged Messages</h4>
                <p className="text-2xl font-bold text-red-900">{flaggedInteractions.length}</p>
              </div>
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <h4 className="font-medium text-green-800 mb-2">Avg Confidence</h4>
                <p className="text-2xl font-bold text-green-900">
                  {Math.round(interactions.reduce((acc, i) => acc + i.sentiment.confidence, 0) / interactions.length)}%
                </p>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="recent" className="space-y-4">
            <ScrollArea className="h-96 w-full">
              <div className="space-y-4">
                {recentInteractions.map((interaction) => (
                  <div key={interaction.id} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center space-x-2">
                        <span className="text-lg">{getTypeIcon(interaction.type)}</span>
                        <span className="text-sm font-medium capitalize">{interaction.type}</span>
                        <span className="text-sm text-muted-foreground">{interaction.date}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        {interaction.flagged && (
                          <Badge variant="destructive" className="text-xs">Flagged</Badge>
                        )}
                        <Badge variant="outline" className={getSentimentColor(interaction.sentiment.emotion)}>
                          {getSentimentIcon(interaction.sentiment.emotion)}
                          <span className="ml-1 capitalize">{interaction.sentiment.emotion}</span>
                        </Badge>
                      </div>
                    </div>
                    <p className="text-sm mb-2">{interaction.content}</p>
                    <div className="flex items-center justify-between text-xs text-muted-foreground">
                      <div className="flex space-x-2">
                        {interaction.sentiment.keywords.slice(0, 3).map((keyword, index) => (
                          <Badge key={index} variant="secondary" className="text-xs">
                            {keyword}
                          </Badge>
                        ))}
                      </div>
                      <span>Confidence: {interaction.sentiment.confidence}%</span>
                    </div>
                  </div>
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="flagged" className="space-y-4">
            {flaggedInteractions.length === 0 ? (
              <div className="text-center py-8 text-muted-foreground">
                <AlertTriangle className="h-8 w-8 mx-auto mb-2" />
                <p>No flagged interactions found</p>
              </div>
            ) : (
              <ScrollArea className="h-96 w-full">
                <div className="space-y-4">
                  {flaggedInteractions.map((interaction) => (
                    <div key={interaction.id} className="p-4 border-2 border-red-200 bg-red-50 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center space-x-2">
                          <AlertTriangle className="h-4 w-4 text-red-600" />
                          <span className="text-sm font-medium text-red-800">Flagged Content</span>
                          <span className="text-sm text-red-600">{interaction.date}</span>
                        </div>
                        <Badge variant="outline" className={getSentimentColor(interaction.sentiment.emotion)}>
                          {getSentimentIcon(interaction.sentiment.emotion)}
                          <span className="ml-1 capitalize">{interaction.sentiment.emotion}</span>
                        </Badge>
                      </div>
                      <p className="text-sm mb-2 text-red-900">{interaction.content}</p>
                      <div className="text-xs text-red-700">
                        <strong>Reason for flagging:</strong> Contains concerning language patterns that may indicate distress or disengagement.
                      </div>
                    </div>
                  ))}
                </div>
              </ScrollArea>
            )}
          </TabsContent>

          <TabsContent value="keywords" className="space-y-4">
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-2">
              {topKeywords.map(([keyword, frequency]) => (
                <div key={keyword} className="p-2 bg-muted/50 rounded text-center">
                  <div className="font-medium text-sm">{keyword}</div>
                  <div className="text-xs text-muted-foreground">{frequency}x</div>
                </div>
              ))}
            </div>
            
            <div className="mt-6">
              <h4 className="font-medium mb-3">Keyword Insights</h4>
              <div className="space-y-2">
                <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <p className="text-sm text-yellow-800">
                    <strong>Emotional Indicators:</strong> High frequency of words like "stressed", "overwhelmed", "difficult" may indicate emotional distress.
                  </p>
                </div>
                <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-sm text-blue-800">
                    <strong>Academic Concerns:</strong> References to "failing", "behind", "confused" suggest need for additional academic support.
                  </p>
                </div>
                <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                  <p className="text-sm text-green-800">
                    <strong>Positive Engagement:</strong> Words like "excited", "interested", "helpful" indicate good engagement levels.
                  </p>
                </div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}