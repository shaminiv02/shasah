import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Progress } from "./ui/progress";
import { 
  Trophy, 
  Crown, 
  Star, 
  TrendingUp, 
  Calendar, 
  Target, 
  Award,
  Flame,
  Medal,
  Zap
} from "lucide-react";

interface LeaderboardEntry {
  id: string;
  name: string;
  avatar?: string;
  rank: number;
  points: number;
  level: number;
  badge: string;
  streak: number;
  weeklyPoints: number;
  improvementRate: number;
  category: 'overall' | 'attendance' | 'assignments' | 'participation';
}

interface LeaderboardProps {
  currentStudentId?: string;
  leaderboardData: {
    overall: LeaderboardEntry[];
    weekly: LeaderboardEntry[];
    streaks: LeaderboardEntry[];
    improvement: LeaderboardEntry[];
  };
}

export function Leaderboard({ currentStudentId, leaderboardData }: LeaderboardProps) {
  const [selectedTab, setSelectedTab] = useState('overall');

  const getRankColor = (rank: number) => {
    switch (rank) {
      case 1: return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 2: return 'text-gray-600 bg-gray-50 border-gray-200';
      case 3: return 'text-amber-700 bg-amber-50 border-amber-200';
      default: return 'text-blue-600 bg-blue-50 border-blue-200';
    }
  };

  const getRankIcon = (rank: number) => {
    switch (rank) {
      case 1: return <Crown className="h-5 w-5 text-yellow-600" />;
      case 2: return <Medal className="h-5 w-5 text-gray-600" />;
      case 3: return <Award className="h-5 w-5 text-amber-700" />;
      default: return <span className="text-sm font-bold text-blue-600">#{rank}</span>;
    }
  };

  const getCurrentStudentRank = (data: LeaderboardEntry[]) => {
    return data.find(entry => entry.id === currentStudentId);
  };

  const renderLeaderboardList = (data: LeaderboardEntry[], showWeekly = false) => (
    <div className="space-y-3">
      {data.slice(0, 10).map((entry, index) => {
        const isCurrentStudent = entry.id === currentStudentId;
        return (
          <div 
            key={entry.id} 
            className={`flex items-center justify-between p-4 rounded-lg border transition-all ${
              isCurrentStudent 
                ? 'bg-blue-50 border-blue-200 ring-2 ring-blue-300' 
                : 'bg-white hover:bg-muted/50'
            }`}
          >
            <div className="flex items-center space-x-4">
              <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${getRankColor(entry.rank)}`}>
                {getRankIcon(entry.rank)}
              </div>
              
              <Avatar className="h-12 w-12">
                <AvatarImage src={entry.avatar} />
                <AvatarFallback>
                  {entry.name.split(' ').map(n => n[0]).join('')}
                </AvatarFallback>
              </Avatar>
              
              <div>
                <div className="flex items-center space-x-2">
                  <h3 className={`font-semibold ${isCurrentStudent ? 'text-blue-800' : ''}`}>
                    {entry.name}
                  </h3>
                  {isCurrentStudent && (
                    <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-800">
                      You
                    </Badge>
                  )}
                </div>
                <div className="flex items-center space-x-3 text-sm text-muted-foreground">
                  <span>Level {entry.level}</span>
                  {entry.streak > 0 && (
                    <div className="flex items-center space-x-1">
                      <Flame className="h-3 w-3 text-orange-500" />
                      <span>{entry.streak} day streak</span>
                    </div>
                  )}
                  <span>{entry.badge}</span>
                </div>
              </div>
            </div>
            
            <div className="text-right">
              <div className="text-lg font-bold">
                {showWeekly ? entry.weeklyPoints : entry.points}
              </div>
              <div className="text-sm text-muted-foreground">
                {showWeekly ? 'This Week' : 'Total Points'}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );

  const currentStudent = getCurrentStudentRank(leaderboardData.overall);

  return (
    <div className="space-y-6">
      {/* Current Student Highlight */}
      {currentStudent && (
        <Card className="bg-gradient-to-r from-purple-500 to-indigo-600 text-white border-0">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <div className="flex items-center justify-center w-16 h-16 rounded-full bg-white/20 border-2 border-white/30">
                  {getRankIcon(currentStudent.rank)}
                </div>
                <div>
                  <h2 className="text-xl font-bold">Your Current Ranking</h2>
                  <p className="text-purple-100">#{currentStudent.rank} out of {leaderboardData.overall.length} students</p>
                  <div className="flex items-center space-x-4 mt-2">
                    <div className="flex items-center space-x-1">
                      <Trophy className="h-4 w-4 text-yellow-300" />
                      <span>{currentStudent.points} points</span>
                    </div>
                    <div className="flex items-center space-x-1">
                      <Flame className="h-4 w-4 text-orange-300" />
                      <span>{currentStudent.streak} day streak</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="text-right">
                <div className="text-sm text-purple-100">Next Rank</div>
                <div className="text-2xl font-bold">
                  {currentStudent.rank > 1 
                    ? `#${currentStudent.rank - 1}` 
                    : '👑 #1'}
                </div>
                {currentStudent.rank > 1 && (
                  <div className="text-sm text-purple-100 mt-1">
                    {leaderboardData.overall[currentStudent.rank - 2]?.points - currentStudent.points} points to go
                  </div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <Trophy className="h-5 w-5 text-yellow-600" />
            <span>Leaderboards</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs value={selectedTab} onValueChange={setSelectedTab} className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="overall" className="flex items-center space-x-1">
                <Trophy className="h-3 w-3" />
                <span className="hidden sm:inline">Overall</span>
              </TabsTrigger>
              <TabsTrigger value="weekly" className="flex items-center space-x-1">
                <Star className="h-3 w-3" />
                <span className="hidden sm:inline">Weekly</span>
              </TabsTrigger>
              <TabsTrigger value="streaks" className="flex items-center space-x-1">
                <Flame className="h-3 w-3" />
                <span className="hidden sm:inline">Streaks</span>
              </TabsTrigger>
              <TabsTrigger value="improvement" className="flex items-center space-x-1">
                <TrendingUp className="h-3 w-3" />
                <span className="hidden sm:inline">Growth</span>
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overall" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Top Performers - All Time</h3>
                <Badge variant="secondary" className="bg-yellow-100 text-yellow-800">
                  <Trophy className="h-3 w-3 mr-1" />
                  Hall of Fame
                </Badge>
              </div>
              {renderLeaderboardList(leaderboardData.overall)}
            </TabsContent>

            <TabsContent value="weekly" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">This Week's Champions</h3>
                <Badge variant="secondary" className="bg-blue-100 text-blue-800">
                  <Calendar className="h-3 w-3 mr-1" />
                  Weekly Reset: Monday
                </Badge>
              </div>
              {renderLeaderboardList(leaderboardData.weekly, true)}
            </TabsContent>

            <TabsContent value="streaks" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Consistency Champions</h3>
                <Badge variant="secondary" className="bg-orange-100 text-orange-800">
                  <Flame className="h-3 w-3 mr-1" />
                  Daily Streaks
                </Badge>
              </div>
              <div className="space-y-3">
                {leaderboardData.streaks.slice(0, 10).map((entry, index) => {
                  const isCurrentStudent = entry.id === currentStudentId;
                  return (
                    <div 
                      key={entry.id} 
                      className={`flex items-center justify-between p-4 rounded-lg border transition-all ${
                        isCurrentStudent 
                          ? 'bg-blue-50 border-blue-200 ring-2 ring-blue-300' 
                          : 'bg-white hover:bg-muted/50'
                      }`}
                    >
                      <div className="flex items-center space-x-4">
                        <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${getRankColor(entry.rank)}`}>
                          {getRankIcon(entry.rank)}
                        </div>
                        
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={entry.avatar} />
                          <AvatarFallback>
                            {entry.name.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        
                        <div>
                          <div className="flex items-center space-x-2">
                            <h3 className={`font-semibold ${isCurrentStudent ? 'text-blue-800' : ''}`}>
                              {entry.name}
                            </h3>
                            {isCurrentStudent && (
                              <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-800">
                                You
                              </Badge>
                            )}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            Level {entry.level} • {entry.badge}
                          </div>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <div className="flex items-center space-x-1 text-lg font-bold text-orange-600">
                          <Flame className="h-5 w-5" />
                          <span>{entry.streak}</span>
                        </div>
                        <div className="text-sm text-muted-foreground">days</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </TabsContent>

            <TabsContent value="improvement" className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold">Most Improved Students</h3>
                <Badge variant="secondary" className="bg-green-100 text-green-800">
                  <TrendingUp className="h-3 w-3 mr-1" />
                  30-Day Progress
                </Badge>
              </div>
              <div className="space-y-3">
                {leaderboardData.improvement.slice(0, 10).map((entry, index) => {
                  const isCurrentStudent = entry.id === currentStudentId;
                  return (
                    <div 
                      key={entry.id} 
                      className={`flex items-center justify-between p-4 rounded-lg border transition-all ${
                        isCurrentStudent 
                          ? 'bg-blue-50 border-blue-200 ring-2 ring-blue-300' 
                          : 'bg-white hover:bg-muted/50'
                      }`}
                    >
                      <div className="flex items-center space-x-4">
                        <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${getRankColor(entry.rank)}`}>
                          {getRankIcon(entry.rank)}
                        </div>
                        
                        <Avatar className="h-12 w-12">
                          <AvatarImage src={entry.avatar} />
                          <AvatarFallback>
                            {entry.name.split(' ').map(n => n[0]).join('')}
                          </AvatarFallback>
                        </Avatar>
                        
                        <div>
                          <div className="flex items-center space-x-2">
                            <h3 className={`font-semibold ${isCurrentStudent ? 'text-blue-800' : ''}`}>
                              {entry.name}
                            </h3>
                            {isCurrentStudent && (
                              <Badge variant="secondary" className="text-xs bg-blue-100 text-blue-800">
                                You
                              </Badge>
                            )}
                          </div>
                          <div className="text-sm text-muted-foreground">
                            Level {entry.level} • {entry.badge}
                          </div>
                        </div>
                      </div>
                      
                      <div className="text-right">
                        <div className="flex items-center space-x-1 text-lg font-bold text-green-600">
                          <TrendingUp className="h-5 w-5" />
                          <span>+{entry.improvementRate}%</span>
                        </div>
                        <div className="text-sm text-muted-foreground">improvement</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}