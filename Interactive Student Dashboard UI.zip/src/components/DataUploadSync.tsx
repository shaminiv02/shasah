import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { Alert, AlertDescription } from "./ui/alert";
import { Upload, Download, RefreshCw, CheckCircle, AlertTriangle, Clock, Database, FileText, MessageSquare } from "lucide-react";

interface UploadStatus {
  id: string;
  filename: string;
  type: 'academic' | 'behavioral' | 'messages';
  status: 'uploading' | 'processing' | 'completed' | 'error';
  progress: number;
  recordsProcessed: number;
  totalRecords: number;
  timestamp: string;
  errorMessage?: string;
}

interface SyncStatus {
  lastSync: string;
  nextSync: string;
  status: 'synced' | 'syncing' | 'error';
  autoSync: boolean;
}

export function DataUploadSync() {
  const [uploads, setUploads] = useState<UploadStatus[]>([
    {
      id: '1',
      filename: 'student_grades_fall2024.csv',
      type: 'academic',
      status: 'completed',
      progress: 100,
      recordsProcessed: 1250,
      totalRecords: 1250,
      timestamp: '2024-03-15 14:30:00'
    },
    {
      id: '2',
      filename: 'attendance_data.xlsx',
      type: 'behavioral',
      status: 'processing',
      progress: 65,
      recordsProcessed: 815,
      totalRecords: 1250,
      timestamp: '2024-03-15 15:45:00'
    }
  ]);

  const [syncStatus, setSyncStatus] = useState<SyncStatus>({
    lastSync: '2024-03-15 14:30:00',
    nextSync: '2024-03-15 18:00:00',
    status: 'synced',
    autoSync: true
  });

  const [isDragging, setIsDragging] = useState(false);

  const handleFileUpload = (file: File, type: 'academic' | 'behavioral' | 'messages') => {
    const newUpload: UploadStatus = {
      id: Date.now().toString(),
      filename: file.name,
      type,
      status: 'uploading',
      progress: 0,
      recordsProcessed: 0,
      totalRecords: 1000, // This would come from file analysis
      timestamp: new Date().toISOString()
    };

    setUploads(prev => [newUpload, ...prev]);

    // Simulate upload progress
    const interval = setInterval(() => {
      setUploads(prev => prev.map(upload => {
        if (upload.id === newUpload.id) {
          const newProgress = Math.min(upload.progress + Math.random() * 20, 100);
          return {
            ...upload,
            progress: newProgress,
            recordsProcessed: Math.floor((newProgress / 100) * upload.totalRecords),
            status: newProgress === 100 ? 'completed' : upload.status
          };
        }
        return upload;
      }));
    }, 500);

    setTimeout(() => {
      clearInterval(interval);
    }, 5000);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent, type: 'academic' | 'behavioral' | 'messages') => {
    e.preventDefault();
    setIsDragging(false);
    
    const files = Array.from(e.dataTransfer.files);
    files.forEach(file => handleFileUpload(file, type));
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'uploading': return <Upload className="h-4 w-4 text-blue-600 animate-pulse" />;
      case 'processing': return <RefreshCw className="h-4 w-4 text-yellow-600 animate-spin" />;
      case 'completed': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'error': return <AlertTriangle className="h-4 w-4 text-red-600" />;
      default: return <Clock className="h-4 w-4 text-gray-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'uploading': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'processing': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'completed': return 'bg-green-100 text-green-800 border-green-200';
      case 'error': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'academic': return <FileText className="h-4 w-4 text-blue-600" />;
      case 'behavioral': return <Database className="h-4 w-4 text-purple-600" />;
      case 'messages': return <MessageSquare className="h-4 w-4 text-green-600" />;
      default: return <FileText className="h-4 w-4 text-gray-600" />;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Database className="h-5 w-5" />
          <span>Data Upload & Synchronization</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="upload" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="upload">Upload Data</TabsTrigger>
            <TabsTrigger value="sync">Sync Status</TabsTrigger>
            <TabsTrigger value="history">Upload History</TabsTrigger>
          </TabsList>

          <TabsContent value="upload" className="space-y-6">
            {/* Academic Data Upload */}
            <div className="space-y-4">
              <h3 className="font-medium flex items-center space-x-2">
                <FileText className="h-4 w-4 text-blue-600" />
                <span>Academic Data</span>
              </h3>
              <div 
                className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
                  isDragging ? 'border-blue-500 bg-blue-50' : 'border-gray-300 hover:border-gray-400'
                }`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={(e) => handleDrop(e, 'academic')}
              >
                <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                <p className="text-sm text-gray-600 mb-2">
                  Drag and drop academic files here, or click to browse
                </p>
                <p className="text-xs text-gray-500 mb-4">
                  Supported formats: CSV, Excel (.xlsx), JSON (Max 50MB)
                </p>
                <Input
                  type="file"
                  accept=".csv,.xlsx,.json"
                  className="hidden"
                  id="academic-upload"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleFileUpload(file, 'academic');
                  }}
                />
                <Label htmlFor="academic-upload">
                  <Button variant="outline" className="cursor-pointer">
                    Select Files
                  </Button>
                </Label>
              </div>
              <div className="text-xs text-gray-500">
                Expected fields: Student ID, Course, Grade, Semester, Assignments, Tests, Participation
              </div>
            </div>

            {/* Behavioral Data Upload */}
            <div className="space-y-4">
              <h3 className="font-medium flex items-center space-x-2">
                <Database className="h-4 w-4 text-purple-600" />
                <span>Behavioral Data</span>
              </h3>
              <div 
                className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
                  isDragging ? 'border-purple-500 bg-purple-50' : 'border-gray-300 hover:border-gray-400'
                }`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={(e) => handleDrop(e, 'behavioral')}
              >
                <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                <p className="text-sm text-gray-600 mb-2">
                  Upload attendance, participation, and engagement data
                </p>
                <Input
                  type="file"
                  accept=".csv,.xlsx,.json"
                  className="hidden"
                  id="behavioral-upload"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleFileUpload(file, 'behavioral');
                  }}
                />
                <Label htmlFor="behavioral-upload">
                  <Button variant="outline" className="cursor-pointer">
                    Select Files
                  </Button>
                </Label>
              </div>
              <div className="text-xs text-gray-500">
                Expected fields: Student ID, Date, Attendance Status, Participation Score, Engagement Level
              </div>
            </div>

            {/* Messages/Feedback Upload */}
            <div className="space-y-4">
              <h3 className="font-medium flex items-center space-x-2">
                <MessageSquare className="h-4 w-4 text-green-600" />
                <span>Student Messages & Feedback</span>
              </h3>
              <div 
                className={`border-2 border-dashed rounded-lg p-6 text-center transition-colors ${
                  isDragging ? 'border-green-500 bg-green-50' : 'border-gray-300 hover:border-gray-400'
                }`}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
                onDrop={(e) => handleDrop(e, 'messages')}
              >
                <Upload className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                <p className="text-sm text-gray-600 mb-2">
                  Upload student communication and feedback data
                </p>
                <Input
                  type="file"
                  accept=".csv,.xlsx,.json,.txt"
                  className="hidden"
                  id="messages-upload"
                  onChange={(e) => {
                    const file = e.target.files?.[0];
                    if (file) handleFileUpload(file, 'messages');
                  }}
                />
                <Label htmlFor="messages-upload">
                  <Button variant="outline" className="cursor-pointer">
                    Select Files
                  </Button>
                </Label>
              </div>
              <div className="text-xs text-gray-500">
                Expected fields: Student ID, Date, Message Content, Type (email/chat/feedback), Source
              </div>
            </div>
          </TabsContent>

          <TabsContent value="sync" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <h3 className="font-medium">Synchronization Status</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-green-50 border border-green-200 rounded-lg">
                    <div className="flex items-center space-x-2">
                      <CheckCircle className="h-4 w-4 text-green-600" />
                      <span className="text-sm">System Status</span>
                    </div>
                    <Badge variant="outline" className="bg-green-100 text-green-800 border-green-200">
                      Synced
                    </Badge>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Last Sync:</span>
                      <span className="font-medium">{syncStatus.lastSync}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Next Sync:</span>
                      <span className="font-medium">{syncStatus.nextSync}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Auto Sync:</span>
                      <Badge variant={syncStatus.autoSync ? "default" : "secondary"}>
                        {syncStatus.autoSync ? "Enabled" : "Disabled"}
                      </Badge>
                    </div>
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="font-medium">Manual Actions</h3>
                <div className="space-y-2">
                  <Button variant="outline" className="w-full justify-start">
                    <RefreshCw className="h-4 w-4 mr-2" />
                    Force Sync Now
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Download className="h-4 w-4 mr-2" />
                    Download System Report
                  </Button>
                  <Button variant="outline" className="w-full justify-start">
                    <Database className="h-4 w-4 mr-2" />
                    Validate Data Integrity
                  </Button>
                </div>
              </div>
            </div>

            <Alert>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                Automatic synchronization runs every 4 hours. Large data uploads may take several minutes to process completely.
              </AlertDescription>
            </Alert>
          </TabsContent>

          <TabsContent value="history" className="space-y-4">
            <div className="space-y-3">
              {uploads.map((upload) => (
                <div key={upload.id} className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      {getTypeIcon(upload.type)}
                      <span className="font-medium text-sm">{upload.filename}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant="outline" className={getStatusColor(upload.status)}>
                        {getStatusIcon(upload.status)}
                        <span className="ml-1 capitalize">{upload.status}</span>
                      </Badge>
                    </div>
                  </div>
                  
                  {upload.status !== 'completed' && (
                    <div className="space-y-2">
                      <Progress value={upload.progress} className="h-2" />
                      <div className="flex justify-between text-xs text-muted-foreground">
                        <span>{upload.recordsProcessed} / {upload.totalRecords} records</span>
                        <span>{upload.progress.toFixed(0)}%</span>
                      </div>
                    </div>
                  )}
                  
                  <div className="flex justify-between items-center mt-2 text-xs text-muted-foreground">
                    <span>Uploaded: {new Date(upload.timestamp).toLocaleString()}</span>
                    <span className="capitalize">{upload.type} Data</span>
                  </div>
                  
                  {upload.errorMessage && (
                    <div className="mt-2 p-2 bg-red-50 border border-red-200 rounded text-xs text-red-800">
                      Error: {upload.errorMessage}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}