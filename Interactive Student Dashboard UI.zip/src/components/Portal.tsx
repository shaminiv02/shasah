import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { 
  Users, 
  GraduationCap, 
  UserCheck, 
  ArrowRight,
  Star,
  Trophy,
  Target,
  Heart,
  BookOpen,
  MessageSquare
} from "lucide-react";

import { StudentPortal } from "./StudentPortal";
import { MentorDashboard } from "./MentorDashboard";

interface PortalProps {}

const mockMentorData = {
  name: "Dr. Sarah Wilson",
  id: "MEN001",
  avatar: "",
  mentees: [
    {
      id: "ST001",
      name: "Alex Thompson", 
      avatar: "",
      level: 12,
      totalPoints: 2847,
      riskScore: 15,
      riskLevel: "Low" as const,
      gpa: 3.6,
      attendance: 92,
      participationScore: 88,
      lastActivity: "2 hours ago",
      currentStreak: 7,
      recentTrend: "up" as const,
      flaggedAlerts: 0,
      completedChallenges: 5,
      activeChallenges: 2
    },
    {
      id: "ST002",
      name: "Marcus Johnson",
      avatar: "",
      level: 8,
      totalPoints: 1420,
      riskScore: 78,
      riskLevel: "High" as const,
      gpa: 2.1,
      attendance: 72,
      participationScore: 45,
      lastActivity: "1 day ago",
      currentStreak: 2,
      recentTrend: "down" as const,
      flaggedAlerts: 3,
      completedChallenges: 1,
      activeChallenges: 3
    },
    {
      id: "ST003",
      name: "Emily Rodriguez",
      avatar: "",
      level: 14,
      totalPoints: 3240,
      riskScore: 35,
      riskLevel: "Medium" as const,
      gpa: 3.2,
      attendance: 88,
      participationScore: 92,
      lastActivity: "5 hours ago",
      currentStreak: 12,
      recentTrend: "up" as const,
      flaggedAlerts: 1,
      completedChallenges: 8,
      activeChallenges: 1
    }
  ],
  analytics: {
    totalMentees: 3,
    averageRiskScore: 43,
    highRiskCount: 1,
    averageGPA: 2.9,
    averageAttendance: 84,
    totalPointsAwarded: 7507,
    challengesCompleted: 14,
    improvementRate: 22
  },
  pendingActions: [
    {
      id: "A001",
      type: "intervention" as const,
      menteeId: "ST002",
      menteeName: "Marcus Johnson",
      description: "Schedule urgent intervention meeting - risk score increased to 78%",
      priority: "high" as const,
      timestamp: "2 hours ago"
    },
    {
      id: "A002",
      type: "reward" as const,
      menteeId: "ST003",
      menteeName: "Emily Rodriguez",
      description: "Award achievement badge for 12-day attendance streak",
      priority: "medium" as const,
      timestamp: "4 hours ago"
    },
    {
      id: "A003",
      type: "checkin" as const,
      menteeId: "ST001",
      menteeName: "Alex Thompson",
      description: "Weekly check-in scheduled for tomorrow",
      priority: "low" as const,
      timestamp: "1 day ago"
    }
  ]
};

export function Portal({}: PortalProps) {
  const [userRole, setUserRole] = useState<"student" | "mentor" | null>(null);

  if (userRole === "student") {
    return <StudentPortal />;
  }

  if (userRole === "mentor") {
    return <MentorDashboard mentorData={mockMentorData} />;
  }

  // Role Selection Landing Page
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50 flex items-center justify-center p-6">
      <div className="max-w-4xl w-full">
        {/* Header */}
        <div className="text-center mb-12">
          <div className="flex justify-center mb-6">
            <div className="p-4 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl shadow-lg">
              <GraduationCap className="h-12 w-12 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-gray-800 mb-4">
            Student Success Portal
          </h1>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Empowering students and mentors with AI-driven insights, gamification, and personalized support to prevent dropout and boost academic success.
          </p>
        </div>

        {/* Role Selection Cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
          {/* Student Portal Card */}
          <Card className="group cursor-pointer transition-all duration-300 hover:shadow-2xl hover:scale-105 border-2 hover:border-blue-300 bg-gradient-to-br from-blue-50 to-indigo-100">
            <CardContent className="p-8" onClick={() => setUserRole("student")}>
              <div className="text-center">
                <div className="flex justify-center mb-6">
                  <div className="p-4 bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl shadow-lg group-hover:shadow-xl transition-all">
                    <Users className="h-8 w-8 text-white" />
                  </div>
                </div>
                
                <h2 className="text-2xl font-bold text-blue-800 mb-4">Student Portal</h2>
                <p className="text-blue-700 mb-6">
                  Track your progress, earn rewards, and get personalized support on your academic journey.
                </p>

                {/* Features Preview */}
                <div className="space-y-3 mb-6">
                  <div className="flex items-center justify-center space-x-2 text-sm text-blue-600">
                    <Trophy className="h-4 w-4" />
                    <span>Gamified Learning Experience</span>
                  </div>
                  <div className="flex items-center justify-center space-x-2 text-sm text-blue-600">
                    <MessageSquare className="h-4 w-4" />
                    <span>AI Counselor Support</span>
                  </div>
                  <div className="flex items-center justify-center space-x-2 text-sm text-blue-600">
                    <Target className="h-4 w-4" />
                    <span>Progress Tracking & Goals</span>
                  </div>
                  <div className="flex items-center justify-center space-x-2 text-sm text-blue-600">
                    <Star className="h-4 w-4" />
                    <span>Leaderboards & Achievements</span>
                  </div>
                </div>

                <Button 
                  className="w-full bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white shadow-lg group-hover:shadow-xl transition-all"
                  onClick={() => setUserRole("student")}
                >
                  Enter Student Portal
                  <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>

                {/* Sample Student Profile */}
                <div className="mt-6 p-4 bg-white/60 rounded-lg border border-blue-200">
                  <div className="flex items-center justify-center space-x-3">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white text-sm">
                        AT
                      </AvatarFallback>
                    </Avatar>
                    <div className="text-left">
                      <div className="text-sm font-medium text-blue-800">Alex Thompson</div>
                      <div className="text-xs text-blue-600">Level 12 • 2,847 Points</div>
                    </div>
                    <Badge className="bg-green-100 text-green-800 border-green-200 text-xs">
                      Low Risk
                    </Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Mentor Portal Card */}
          <Card className="group cursor-pointer transition-all duration-300 hover:shadow-2xl hover:scale-105 border-2 hover:border-purple-300 bg-gradient-to-br from-purple-50 to-indigo-100">
            <CardContent className="p-8" onClick={() => setUserRole("mentor")}>
              <div className="text-center">
                <div className="flex justify-center mb-6">
                  <div className="p-4 bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl shadow-lg group-hover:shadow-xl transition-all">
                    <UserCheck className="h-8 w-8 text-white" />
                  </div>
                </div>
                
                <h2 className="text-2xl font-bold text-purple-800 mb-4">Mentor Dashboard</h2>
                <p className="text-purple-700 mb-6">
                  Monitor your mentees, identify at-risk students, and provide targeted interventions and support.
                </p>

                {/* Features Preview */}
                <div className="space-y-3 mb-6">
                  <div className="flex items-center justify-center space-x-2 text-sm text-purple-600">
                    <Users className="h-4 w-4" />
                    <span>Mentee Progress Tracking</span>
                  </div>
                  <div className="flex items-center justify-center space-x-2 text-sm text-purple-600">
                    <Heart className="h-4 w-4" />
                    <span>Risk Assessment & Alerts</span>
                  </div>
                  <div className="flex items-center justify-center space-x-2 text-sm text-purple-600">
                    <Target className="h-4 w-4" />
                    <span>Intervention Tools</span>
                  </div>
                  <div className="flex items-center justify-center space-x-2 text-sm text-purple-600">
                    <BookOpen className="h-4 w-4" />
                    <span>Analytics & Reporting</span>
                  </div>
                </div>

                <Button 
                  className="w-full bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white shadow-lg group-hover:shadow-xl transition-all"
                  onClick={() => setUserRole("mentor")}
                >
                  Enter Mentor Dashboard
                  <ArrowRight className="h-4 w-4 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>

                {/* Sample Mentor Profile */}
                <div className="mt-6 p-4 bg-white/60 rounded-lg border border-purple-200">
                  <div className="flex items-center justify-center space-x-3">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback className="bg-gradient-to-br from-purple-500 to-indigo-600 text-white text-sm">
                        SW
                      </AvatarFallback>
                    </Avatar>
                    <div className="text-left">
                      <div className="text-sm font-medium text-purple-800">Dr. Sarah Wilson</div>
                      <div className="text-xs text-purple-600">3 Mentees • 7,507 Points Awarded</div>
                    </div>
                    <Badge className="bg-red-100 text-red-800 border-red-200 text-xs">
                      1 High Risk
                    </Badge>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Key Features Section */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          <Card className="text-center p-6 bg-white/70 border-gray-200">
            <div className="p-3 bg-green-100 rounded-full w-fit mx-auto mb-4">
              <Trophy className="h-6 w-6 text-green-600" />
            </div>
            <h3 className="font-semibold text-gray-800 mb-2">Gamification</h3>
            <p className="text-sm text-gray-600">
              Points, badges, achievements, and leaderboards to make learning engaging and motivating.
            </p>
          </Card>

          <Card className="text-center p-6 bg-white/70 border-gray-200">
            <div className="p-3 bg-blue-100 rounded-full w-fit mx-auto mb-4">
              <MessageSquare className="h-6 w-6 text-blue-600" />
            </div>
            <h3 className="font-semibold text-gray-800 mb-2">AI Support</h3>
            <p className="text-sm text-gray-600">
              Intelligent counseling, personalized tips, and real-time sentiment analysis for student messages.
            </p>
          </Card>

          <Card className="text-center p-6 bg-white/70 border-gray-200">
            <div className="p-3 bg-purple-100 rounded-full w-fit mx-auto mb-4">
              <Heart className="h-6 w-6 text-purple-600" />
            </div>
            <h3 className="font-semibold text-gray-800 mb-2">Early Intervention</h3>
            <p className="text-sm text-gray-600">
              Predictive analytics and risk assessment to identify and support at-risk students before it's too late.
            </p>
          </Card>
        </div>

        {/* Footer */}
        <div className="text-center text-gray-500 text-sm">
          <p>Designed to create positive educational outcomes through technology, engagement, and human connection.</p>
        </div>
      </div>
    </div>
  );
}