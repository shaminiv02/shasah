import { useState } from "react";
import { Input } from "./ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "./ui/select";
import { Button } from "./ui/button";
import { Badge } from "./ui/badge";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Search, Filter, X, Users, GraduationCap, AlertTriangle, CheckCircle } from "lucide-react";

interface FilterState {
  search: string;
  riskLevel: string;
  academicYear: string;
  enrollmentStatus: string;
  grade: string;
  gpaRange: string;
  attendanceRange: string;
}

interface FiltersAndSearchProps {
  onFiltersChange: (filters: FilterState) => void;
  totalStudents: number;
  filteredStudents: number;
}

export function FiltersAndSearch({ onFiltersChange, totalStudents, filteredStudents }: FiltersAndSearchProps) {
  const [filters, setFilters] = useState<FilterState>({
    search: '',
    riskLevel: '',
    academicYear: '',
    enrollmentStatus: '',
    grade: '',
    gpaRange: '',
    attendanceRange: ''
  });

  const [showAdvanced, setShowAdvanced] = useState(false);

  const updateFilter = (key: keyof FilterState, value: string) => {
    const newFilters = { ...filters, [key]: value };
    setFilters(newFilters);
    onFiltersChange(newFilters);
  };

  const clearFilters = () => {
    const emptyFilters = {
      search: '',
      riskLevel: '',
      academicYear: '',
      enrollmentStatus: '',
      grade: '',
      gpaRange: '',
      attendanceRange: ''
    };
    setFilters(emptyFilters);
    onFiltersChange(emptyFilters);
  };

  const getActiveFiltersCount = () => {
    return Object.values(filters).filter(value => value !== '').length;
  };

  const hasActiveFilters = getActiveFiltersCount() > 0;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Filter className="h-5 w-5" />
            <span>Filters & Search</span>
          </div>
          <div className="flex items-center space-x-4 text-sm text-muted-foreground">
            <div className="flex items-center space-x-2">
              <Users className="h-4 w-4" />
              <span>Showing {filteredStudents} of {totalStudents} students</span>
            </div>
            {hasActiveFilters && (
              <Badge variant="secondary">
                {getActiveFiltersCount()} filter{getActiveFiltersCount() !== 1 ? 's' : ''} active
              </Badge>
            )}
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Search and Quick Filters */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search by name or student ID..."
              value={filters.search}
              onChange={(e) => updateFilter('search', e.target.value)}
              className="pl-10"
            />
          </div>

          <Select value={filters.riskLevel} onValueChange={(value) => updateFilter('riskLevel', value)}>
            <SelectTrigger>
              <SelectValue placeholder="Risk Level" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Low">
                <div className="flex items-center space-x-2">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span>Low Risk</span>
                </div>
              </SelectItem>
              <SelectItem value="Medium">
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="h-4 w-4 text-yellow-600" />
                  <span>Medium Risk</span>
                </div>
              </SelectItem>
              <SelectItem value="High">
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="h-4 w-4 text-orange-600" />
                  <span>High Risk</span>
                </div>
              </SelectItem>
              <SelectItem value="Critical">
                <div className="flex items-center space-x-2">
                  <AlertTriangle className="h-4 w-4 text-red-600" />
                  <span>Critical Risk</span>
                </div>
              </SelectItem>
            </SelectContent>
          </Select>

          <Select value={filters.enrollmentStatus} onValueChange={(value) => updateFilter('enrollmentStatus', value)}>
            <SelectTrigger>
              <SelectValue placeholder="Enrollment Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="Active">Active</SelectItem>
              <SelectItem value="Probation">Probation</SelectItem>
              <SelectItem value="Inactive">Inactive</SelectItem>
            </SelectContent>
          </Select>

          <Select value={filters.academicYear} onValueChange={(value) => updateFilter('academicYear', value)}>
            <SelectTrigger>
              <SelectValue placeholder="Academic Year" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="2024-2025">2024-2025</SelectItem>
              <SelectItem value="2023-2024">2023-2024</SelectItem>
              <SelectItem value="2022-2023">2022-2023</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Advanced Filters Toggle */}
        <div className="flex items-center justify-between">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowAdvanced(!showAdvanced)}
          >
            {showAdvanced ? 'Hide' : 'Show'} Advanced Filters
          </Button>
          
          {hasActiveFilters && (
            <Button
              variant="ghost"
              size="sm"
              onClick={clearFilters}
              className="text-muted-foreground hover:text-foreground"
            >
              <X className="h-4 w-4 mr-2" />
              Clear All Filters
            </Button>
          )}
        </div>

        {/* Advanced Filters */}
        {showAdvanced && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-4 border-t">
            <Select value={filters.grade} onValueChange={(value) => updateFilter('grade', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Grade Level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="9th Grade">9th Grade</SelectItem>
                <SelectItem value="10th Grade">10th Grade</SelectItem>
                <SelectItem value="11th Grade">11th Grade</SelectItem>
                <SelectItem value="12th Grade">12th Grade</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filters.gpaRange} onValueChange={(value) => updateFilter('gpaRange', value)}>
              <SelectTrigger>
                <SelectValue placeholder="GPA Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="3.5-4.0">3.5 - 4.0 (Excellent)</SelectItem>
                <SelectItem value="3.0-3.4">3.0 - 3.4 (Good)</SelectItem>
                <SelectItem value="2.5-2.9">2.5 - 2.9 (Average)</SelectItem>
                <SelectItem value="2.0-2.4">2.0 - 2.4 (Below Average)</SelectItem>
                <SelectItem value="0.0-1.9">0.0 - 1.9 (Poor)</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filters.attendanceRange} onValueChange={(value) => updateFilter('attendanceRange', value)}>
              <SelectTrigger>
                <SelectValue placeholder="Attendance Rate" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="90-100">90% - 100% (Excellent)</SelectItem>
                <SelectItem value="80-89">80% - 89% (Good)</SelectItem>
                <SelectItem value="70-79">70% - 79% (Fair)</SelectItem>
                <SelectItem value="60-69">60% - 69% (Poor)</SelectItem>
                <SelectItem value="0-59">Below 60% (Critical)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}

        {/* Active Filters Display */}
        {hasActiveFilters && (
          <div className="space-y-2">
            <div className="text-sm font-medium">Active Filters:</div>
            <div className="flex flex-wrap gap-2">
              {filters.search && (
                <Badge variant="secondary" className="flex items-center space-x-1">
                  <span>Search: "{filters.search}"</span>
                  <X 
                    className="h-3 w-3 cursor-pointer" 
                    onClick={() => updateFilter('search', '')}
                  />
                </Badge>
              )}
              {filters.riskLevel && (
                <Badge variant="secondary" className="flex items-center space-x-1">
                  <span>Risk: {filters.riskLevel}</span>
                  <X 
                    className="h-3 w-3 cursor-pointer" 
                    onClick={() => updateFilter('riskLevel', '')}
                  />
                </Badge>
              )}
              {filters.enrollmentStatus && (
                <Badge variant="secondary" className="flex items-center space-x-1">
                  <span>Status: {filters.enrollmentStatus}</span>
                  <X 
                    className="h-3 w-3 cursor-pointer" 
                    onClick={() => updateFilter('enrollmentStatus', '')}
                  />
                </Badge>
              )}
              {filters.academicYear && (
                <Badge variant="secondary" className="flex items-center space-x-1">
                  <span>Year: {filters.academicYear}</span>
                  <X 
                    className="h-3 w-3 cursor-pointer" 
                    onClick={() => updateFilter('academicYear', '')}
                  />
                </Badge>
              )}
              {filters.grade && (
                <Badge variant="secondary" className="flex items-center space-x-1">
                  <span>Grade: {filters.grade}</span>
                  <X 
                    className="h-3 w-3 cursor-pointer" 
                    onClick={() => updateFilter('grade', '')}
                  />
                </Badge>
              )}
              {filters.gpaRange && (
                <Badge variant="secondary" className="flex items-center space-x-1">
                  <span>GPA: {filters.gpaRange}</span>
                  <X 
                    className="h-3 w-3 cursor-pointer" 
                    onClick={() => updateFilter('gpaRange', '')}
                  />
                </Badge>
              )}
              {filters.attendanceRange && (
                <Badge variant="secondary" className="flex items-center space-x-1">
                  <span>Attendance: {filters.attendanceRange}</span>
                  <X 
                    className="h-3 w-3 cursor-pointer" 
                    onClick={() => updateFilter('attendanceRange', '')}
                  />
                </Badge>
              )}
            </div>
          </div>
        )}

        {/* Quick Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 border-t">
          <div className="text-center p-2 bg-red-50 rounded border border-red-200">
            <div className="text-sm text-red-600">Critical Risk</div>
            <div className="font-semibold text-red-800">12</div>
          </div>
          <div className="text-center p-2 bg-orange-50 rounded border border-orange-200">
            <div className="text-sm text-orange-600">High Risk</div>
            <div className="font-semibold text-orange-800">28</div>
          </div>
          <div className="text-center p-2 bg-yellow-50 rounded border border-yellow-200">
            <div className="text-sm text-yellow-600">Medium Risk</div>
            <div className="font-semibold text-yellow-800">45</div>
          </div>
          <div className="text-center p-2 bg-green-50 rounded border border-green-200">
            <div className="text-sm text-green-600">Low Risk</div>
            <div className="font-semibold text-green-800">156</div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}