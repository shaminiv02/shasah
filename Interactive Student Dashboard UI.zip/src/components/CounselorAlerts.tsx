import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Alert, AlertDescription } from "./ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { ScrollArea } from "./ui/scroll-area";
import { AlertTriangle, Clock, CheckCircle, MessageSquare, Calendar, Bell, User, TrendingDown, TrendingUp, X } from "lucide-react";

interface AlertItem {
  id: string;
  studentId: string;
  studentName: string;
  type: 'risk_increase' | 'attendance_drop' | 'grade_decline' | 'engagement_low' | 'message_flag' | 'deadline_missed';
  severity: 'low' | 'medium' | 'high' | 'critical';
  title: string;
  description: string;
  recommendation: string;
  timestamp: string;
  isRead: boolean;
  isActionTaken: boolean;
}

interface CounselorAlertsProps {
  alerts: AlertItem[];
  onMarkAsRead: (alertId: string) => void;
  onMarkActionTaken: (alertId: string) => void;
  onDismissAlert: (alertId: string) => void;
}

export function CounselorAlerts({ alerts, onMarkAsRead, onMarkActionTaken, onDismissAlert }: CounselorAlertsProps) {
  const [selectedAlert, setSelectedAlert] = useState<AlertItem | null>(null);

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'low': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'high': return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'critical': return 'bg-red-100 text-red-800 border-red-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'low': return <Bell className="h-4 w-4 text-blue-600" />;
      case 'medium': return <Clock className="h-4 w-4 text-yellow-600" />;
      case 'high': return <AlertTriangle className="h-4 w-4 text-orange-600" />;
      case 'critical': return <AlertTriangle className="h-4 w-4 text-red-600" />;
      default: return <Bell className="h-4 w-4 text-gray-600" />;
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'risk_increase': return <TrendingUp className="h-4 w-4 text-red-600" />;
      case 'attendance_drop': return <Calendar className="h-4 w-4 text-orange-600" />;
      case 'grade_decline': return <TrendingDown className="h-4 w-4 text-red-600" />;
      case 'engagement_low': return <User className="h-4 w-4 text-yellow-600" />;
      case 'message_flag': return <MessageSquare className="h-4 w-4 text-purple-600" />;
      case 'deadline_missed': return <Clock className="h-4 w-4 text-red-600" />;
      default: return <Bell className="h-4 w-4 text-gray-600" />;
    }
  };

  const unreadAlerts = alerts.filter(alert => !alert.isRead);
  const criticalAlerts = alerts.filter(alert => alert.severity === 'critical');
  const actionNeededAlerts = alerts.filter(alert => !alert.isActionTaken && alert.isRead);

  const formatTimeAgo = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInHours = Math.floor((now.getTime() - date.getTime()) / (1000 * 60 * 60));
    
    if (diffInHours < 1) return 'Just now';
    if (diffInHours < 24) return `${diffInHours}h ago`;
    const diffInDays = Math.floor(diffInHours / 24);
    return `${diffInDays}d ago`;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <AlertTriangle className="h-5 w-5" />
            <span>Counselor Alerts</span>
          </div>
          <div className="flex items-center space-x-2">
            <Badge variant="destructive" className="text-xs">
              {unreadAlerts.length} unread
            </Badge>
            <Badge variant="outline" className="text-xs">
              {criticalAlerts.length} critical
            </Badge>
          </div>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="all" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="all">All ({alerts.length})</TabsTrigger>
            <TabsTrigger value="unread">Unread ({unreadAlerts.length})</TabsTrigger>
            <TabsTrigger value="critical">Critical ({criticalAlerts.length})</TabsTrigger>
            <TabsTrigger value="action">Action Needed ({actionNeededAlerts.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="all" className="space-y-4">
            <ScrollArea className="h-96 w-full">
              <div className="space-y-3">
                {alerts.map((alert) => (
                  <AlertCard 
                    key={alert.id} 
                    alert={alert}
                    onMarkAsRead={onMarkAsRead}
                    onMarkActionTaken={onMarkActionTaken}
                    onDismissAlert={onDismissAlert}
                    onSelect={setSelectedAlert}
                    getSeverityColor={getSeverityColor}
                    getSeverityIcon={getSeverityIcon}
                    getTypeIcon={getTypeIcon}
                    formatTimeAgo={formatTimeAgo}
                  />
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="unread" className="space-y-4">
            <ScrollArea className="h-96 w-full">
              <div className="space-y-3">
                {unreadAlerts.map((alert) => (
                  <AlertCard 
                    key={alert.id} 
                    alert={alert}
                    onMarkAsRead={onMarkAsRead}
                    onMarkActionTaken={onMarkActionTaken}
                    onDismissAlert={onDismissAlert}
                    onSelect={setSelectedAlert}
                    getSeverityColor={getSeverityColor}
                    getSeverityIcon={getSeverityIcon}
                    getTypeIcon={getTypeIcon}
                    formatTimeAgo={formatTimeAgo}
                  />
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="critical" className="space-y-4">
            <Alert className="border-red-200 bg-red-50">
              <AlertTriangle className="h-4 w-4 text-red-600" />
              <AlertDescription className="text-red-800">
                {criticalAlerts.length} students require immediate attention. Please review and take action promptly.
              </AlertDescription>
            </Alert>
            <ScrollArea className="h-80 w-full">
              <div className="space-y-3">
                {criticalAlerts.map((alert) => (
                  <AlertCard 
                    key={alert.id} 
                    alert={alert}
                    onMarkAsRead={onMarkAsRead}
                    onMarkActionTaken={onMarkActionTaken}
                    onDismissAlert={onDismissAlert}
                    onSelect={setSelectedAlert}
                    getSeverityColor={getSeverityColor}
                    getSeverityIcon={getSeverityIcon}
                    getTypeIcon={getTypeIcon}
                    formatTimeAgo={formatTimeAgo}
                  />
                ))}
              </div>
            </ScrollArea>
          </TabsContent>

          <TabsContent value="action" className="space-y-4">
            <Alert className="border-yellow-200 bg-yellow-50">
              <Clock className="h-4 w-4 text-yellow-600" />
              <AlertDescription className="text-yellow-800">
                {actionNeededAlerts.length} alerts are awaiting action from counselors.
              </AlertDescription>
            </Alert>
            <ScrollArea className="h-80 w-full">
              <div className="space-y-3">
                {actionNeededAlerts.map((alert) => (
                  <AlertCard 
                    key={alert.id} 
                    alert={alert}
                    onMarkAsRead={onMarkAsRead}
                    onMarkActionTaken={onMarkActionTaken}
                    onDismissAlert={onDismissAlert}
                    onSelect={setSelectedAlert}
                    getSeverityColor={getSeverityColor}
                    getSeverityIcon={getSeverityIcon}
                    getTypeIcon={getTypeIcon}
                    formatTimeAgo={formatTimeAgo}
                  />
                ))}
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

interface AlertCardProps {
  alert: AlertItem;
  onMarkAsRead: (alertId: string) => void;
  onMarkActionTaken: (alertId: string) => void;
  onDismissAlert: (alertId: string) => void;
  onSelect: (alert: AlertItem) => void;
  getSeverityColor: (severity: string) => string;
  getSeverityIcon: (severity: string) => JSX.Element;
  getTypeIcon: (type: string) => JSX.Element;
  formatTimeAgo: (timestamp: string) => string;
}

function AlertCard({ 
  alert, 
  onMarkAsRead, 
  onMarkActionTaken, 
  onDismissAlert, 
  onSelect,
  getSeverityColor,
  getSeverityIcon,
  getTypeIcon,
  formatTimeAgo
}: AlertCardProps) {
  return (
    <div 
      className={`p-4 border rounded-lg cursor-pointer transition-colors hover:bg-muted/50 ${
        !alert.isRead ? 'bg-blue-50 border-blue-200' : 'bg-white'
      }`}
      onClick={() => onSelect(alert)}
    >
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center space-x-2">
          {getTypeIcon(alert.type)}
          <div>
            <h4 className="font-medium text-sm">{alert.title}</h4>
            <p className="text-xs text-muted-foreground">{alert.studentName} (ID: {alert.studentId})</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <Badge variant="outline" className={getSeverityColor(alert.severity)}>
            {getSeverityIcon(alert.severity)}
            <span className="ml-1 capitalize">{alert.severity}</span>
          </Badge>
          <Button
            variant="ghost"
            size="sm"
            onClick={(e) => {
              e.stopPropagation();
              onDismissAlert(alert.id);
            }}
          >
            <X className="h-3 w-3" />
          </Button>
        </div>
      </div>
      
      <p className="text-sm text-muted-foreground mb-3">{alert.description}</p>
      
      <div className="flex items-center justify-between">
        <span className="text-xs text-muted-foreground">{formatTimeAgo(alert.timestamp)}</span>
        <div className="flex space-x-2">
          {!alert.isRead && (
            <Button
              variant="outline"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                onMarkAsRead(alert.id);
              }}
            >
              Mark as Read
            </Button>
          )}
          {alert.isRead && !alert.isActionTaken && (
            <Button
              variant="default"
              size="sm"
              onClick={(e) => {
                e.stopPropagation();
                onMarkActionTaken(alert.id);
              }}
            >
              <CheckCircle className="h-3 w-3 mr-1" />
              Action Taken
            </Button>
          )}
          {alert.isActionTaken && (
            <Badge variant="secondary" className="text-xs">
              <CheckCircle className="h-3 w-3 mr-1" />
              Completed
            </Badge>
          )}
        </div>
      </div>

      <div className="mt-3 p-2 bg-muted/50 rounded text-xs">
        <strong>Recommendation:</strong> {alert.recommendation}
      </div>
    </div>
  );
}