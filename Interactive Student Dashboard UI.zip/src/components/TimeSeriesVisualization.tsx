import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "./ui/tabs";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from "recharts";

interface TimeSeriesData {
  month: string;
  grade: number;
  attendance: number;
  participation: number;
  assignments: number;
  riskScore: number;
}

interface TimeSeriesVisualizationProps {
  data: TimeSeriesData[];
  studentName?: string;
}

export function TimeSeriesVisualization({ data, studentName }: TimeSeriesVisualizationProps) {
  return (
    <Card>
      <CardHeader>
        <CardTitle>
          Student Progress Timeline {studentName && `- ${studentName}`}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="academic">Academic</TabsTrigger>
            <TabsTrigger value="engagement">Engagement</TabsTrigger>
            <TabsTrigger value="risk">Risk Analysis</TabsTrigger>
          </TabsList>
          
          <TabsContent value="overview" className="space-y-4">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="grade" 
                    stroke="var(--color-chart-1)" 
                    strokeWidth={2}
                    name="Grade (GPA)"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="attendance" 
                    stroke="var(--color-chart-2)" 
                    strokeWidth={2}
                    name="Attendance %"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="participation" 
                    stroke="var(--color-chart-3)" 
                    strokeWidth={2}
                    name="Participation %"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>

          <TabsContent value="academic" className="space-y-4">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area 
                    type="monotone" 
                    dataKey="grade" 
                    stackId="1"
                    stroke="var(--color-chart-1)" 
                    fill="var(--color-chart-1)"
                    fillOpacity={0.6}
                    name="Grade (GPA)"
                  />
                  <Area 
                    type="monotone" 
                    dataKey="assignments" 
                    stackId="2"
                    stroke="var(--color-chart-4)" 
                    fill="var(--color-chart-4)"
                    fillOpacity={0.6}
                    name="Assignment Completion %"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>

          <TabsContent value="engagement" className="space-y-4">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line 
                    type="monotone" 
                    dataKey="attendance" 
                    stroke="var(--color-chart-2)" 
                    strokeWidth={3}
                    name="Attendance %"
                  />
                  <Line 
                    type="monotone" 
                    dataKey="participation" 
                    stroke="var(--color-chart-3)" 
                    strokeWidth={3}
                    name="Participation Score %"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>

          <TabsContent value="risk" className="space-y-4">
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="month" />
                  <YAxis domain={[0, 100]} />
                  <Tooltip />
                  <Legend />
                  <Area 
                    type="monotone" 
                    dataKey="riskScore" 
                    stroke="#ef4444" 
                    fill="#ef4444"
                    fillOpacity={0.3}
                    name="Dropout Risk %"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center p-4 bg-green-50 rounded-lg border border-green-200">
                <div className="text-sm text-green-600">Low Risk</div>
                <div className="text-lg font-semibold text-green-800">0-30%</div>
              </div>
              <div className="text-center p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                <div className="text-sm text-yellow-600">Medium Risk</div>
                <div className="text-lg font-semibold text-yellow-800">31-60%</div>
              </div>
              <div className="text-center p-4 bg-red-50 rounded-lg border border-red-200">
                <div className="text-sm text-red-600">High Risk</div>
                <div className="text-lg font-semibold text-red-800">61-100%</div>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}