import { useState } from "react";
import { Sidebar, SidebarContent, SidebarHeader, SidebarMenu, SidebarMenuItem, SidebarMenuButton, SidebarProvider, SidebarTrigger } from "./ui/sidebar";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Badge } from "./ui/badge";
import { Button } from "./ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { 
  Home,
  Trophy, 
  MessageSquare, 
  Target, 
  Settings, 
  User,
  GraduationCap,
  Star,
  Gift,
  BarChart3,
  Calendar,
  BookOpen
} from "lucide-react";

import { StudentDashboard } from "./StudentDashboard";
import { AICounselorChat } from "./AICounselorChat";
import { Leaderboard } from "./Leaderboard";
import { TimeSeriesVisualization } from "./TimeSeriesVisualization";

// Enhanced mock data for student portal
const mockStudentData = {
  name: "Alex Thompson",
  id: "ST2024001",
  avatar: "",
  stats: {
    totalPoints: 2847,
    level: 12,
    currentStreak: 7,
    gpa: 3.6,
    attendance: 92,
    assignmentsCompleted: 28,
    totalAssignments: 32,
    participationScore: 88,
    riskLevel: "Low" as const,
    motivationalMessage: "Great job maintaining your streak! Your consistent attendance is paying off. Consider joining a study group to boost your participation scores even higher.",
    nextLevelPoints: 3000,
    currentLevelPoints: 2750
  },
  achievements: [
    {
      id: "1",
      title: "Perfect Attendance",
      description: "Attend all classes for a full week",
      icon: "🎯",
      earned: true,
      points: 100
    },
    {
      id: "2", 
      title: "Study Streak",
      description: "Complete assignments 5 days in a row",
      icon: "🔥",
      earned: true,
      points: 150
    },
    {
      id: "3",
      title: "Participation Star",
      description: "Participate actively in 10 classes",
      icon: "⭐",
      earned: false,
      progress: 7,
      maxProgress: 10,
      points: 120
    },
    {
      id: "4",
      title: "Grade Improver",
      description: "Improve GPA by 0.5 points",
      icon: "📈",
      earned: false,
      progress: 2,
      maxProgress: 5,
      points: 200
    }
  ],
  recentActivities: [
    {
      id: "1",
      type: "assignment" as const,
      description: "Submitted Math homework on time",
      points: 25,
      timestamp: "2 hours ago"
    },
    {
      id: "2",
      type: "attendance" as const,
      description: "Perfect attendance for the week",
      points: 50,
      timestamp: "1 day ago"
    },
    {
      id: "3",
      type: "participation" as const,
      description: "Active participation in English class",
      points: 15,
      timestamp: "2 days ago"
    },
    {
      id: "4",
      type: "achievement" as const,
      description: "Unlocked Study Streak achievement",
      points: 150,
      timestamp: "3 days ago"
    }
  ]
};

const mockTimeSeriesData = [
  { month: "Sep", grade: 3.4, attendance: 88, participation: 75, assignments: 85, riskScore: 35 },
  { month: "Oct", grade: 3.5, attendance: 90, participation: 80, assignments: 88, riskScore: 28 },
  { month: "Nov", grade: 3.6, attendance: 92, participation: 85, assignments: 90, riskScore: 22 },
  { month: "Dec", grade: 3.6, attendance: 94, participation: 88, assignments: 87, riskScore: 18 },
  { month: "Jan", grade: 3.6, attendance: 92, participation: 88, assignments: 88, riskScore: 15 }
];

const mockLeaderboardData = {
  overall: [
    { id: "ST001", name: "Sarah Chen", rank: 1, points: 4250, level: 18, badge: "Scholar", streak: 15, weeklyPoints: 320, improvementRate: 25 },
    { id: "ST002", name: "Marcus Williams", rank: 2, points: 3890, level: 16, badge: "Achiever", streak: 12, weeklyPoints: 280, improvementRate: 18 },
    { id: "ST2024001", name: "Alex Thompson", rank: 3, points: 2847, level: 12, badge: "Rising Star", streak: 7, weeklyPoints: 195, improvementRate: 32 },
    { id: "ST004", name: "Emily Rodriguez", rank: 4, points: 2650, level: 11, badge: "Consistent", streak: 9, weeklyPoints: 165, improvementRate: 15 },
    { id: "ST005", name: "David Park", rank: 5, points: 2420, level: 10, badge: "Dedicated", streak: 5, weeklyPoints: 140, improvementRate: 22 }
  ],
  weekly: [
    { id: "ST2024001", name: "Alex Thompson", rank: 1, points: 195, level: 12, badge: "Rising Star", streak: 7, weeklyPoints: 195, improvementRate: 32 },
    { id: "ST001", name: "Sarah Chen", rank: 2, points: 320, level: 18, badge: "Scholar", streak: 15, weeklyPoints: 180, improvementRate: 25 },
    { id: "ST004", name: "Emily Rodriguez", rank: 3, points: 165, level: 11, badge: "Consistent", streak: 9, weeklyPoints: 165, improvementRate: 15 }
  ],
  streaks: [
    { id: "ST001", name: "Sarah Chen", rank: 1, points: 4250, level: 18, badge: "Scholar", streak: 15, weeklyPoints: 320, improvementRate: 25 },
    { id: "ST002", name: "Marcus Williams", rank: 2, points: 3890, level: 16, badge: "Achiever", streak: 12, weeklyPoints: 280, improvementRate: 18 },
    { id: "ST004", name: "Emily Rodriguez", rank: 3, points: 2650, level: 11, badge: "Consistent", streak: 9, weeklyPoints: 165, improvementRate: 15 },
    { id: "ST2024001", name: "Alex Thompson", rank: 4, points: 2847, level: 12, badge: "Rising Star", streak: 7, weeklyPoints: 195, improvementRate: 32 }
  ],
  improvement: [
    { id: "ST2024001", name: "Alex Thompson", rank: 1, points: 2847, level: 12, badge: "Rising Star", streak: 7, weeklyPoints: 195, improvementRate: 32 },
    { id: "ST001", name: "Sarah Chen", rank: 2, points: 4250, level: 18, badge: "Scholar", streak: 15, weeklyPoints: 320, improvementRate: 25 },
    { id: "ST005", name: "David Park", rank: 3, points: 2420, level: 10, badge: "Dedicated", streak: 5, weeklyPoints: 140, improvementRate: 22 }
  ]
};

export function StudentPortal() {
  const [activeView, setActiveView] = useState("dashboard");

  const sidebarItems = [
    { id: "dashboard", label: "Dashboard", icon: Home },
    { id: "progress", label: "My Progress", icon: BarChart3 },
    { id: "leaderboard", label: "Leaderboard", icon: Trophy },
    { id: "challenges", label: "Challenges", icon: Target },
    { id: "rewards", label: "Rewards", icon: Gift },
    { id: "counselor", label: "AI Counselor", icon: MessageSquare },
    { id: "calendar", label: "Calendar", icon: Calendar },
    { id: "profile", label: "Profile", icon: User }
  ];

  return (
    <SidebarProvider>
      <div className="flex min-h-screen w-full bg-gradient-to-br from-blue-50 via-white to-purple-50">
        <Sidebar className="bg-white/80 backdrop-blur-sm border-r border-gray-200">
          <SidebarHeader className="border-b border-gray-200 p-4 bg-white/50">
            <div className="flex items-center space-x-2">
              <div className="p-2 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg">
                <GraduationCap className="h-5 w-5 text-white" />
              </div>
              <div>
                <div className="font-semibold text-gray-800">Student Portal</div>
                <div className="text-xs text-gray-600">Welcome back, Alex!</div>
              </div>
            </div>
          </SidebarHeader>
          <SidebarContent className="p-2">
            <SidebarMenu>
              {sidebarItems.map((item) => (
                <SidebarMenuItem key={item.id}>
                  <SidebarMenuButton 
                    onClick={() => setActiveView(item.id)}
                    isActive={activeView === item.id}
                    className="w-full text-gray-700 hover:text-gray-900 hover:bg-white/70"
                  >
                    <item.icon className="h-4 w-4" />
                    <span>{item.label}</span>
                    {item.id === "counselor" && (
                      <div className="ml-auto w-2 h-2 bg-green-500 rounded-full"></div>
                    )}
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarContent>
        </Sidebar>

        <main className="flex-1 p-6 space-y-6 overflow-auto">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <SidebarTrigger />
              <h1 className="text-2xl font-semibold text-gray-800">
                {sidebarItems.find(item => item.id === activeView)?.label || "Dashboard"}
              </h1>
            </div>
            <div className="flex items-center space-x-3">
              <Badge variant="secondary" className="bg-green-100 text-green-800 border-green-200">
                <div className="w-2 h-2 bg-green-500 rounded-full mr-2"></div>
                Low Risk
              </Badge>
              <Avatar className="h-8 w-8">
                <AvatarImage src={mockStudentData.avatar} />
                <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white">
                  AT
                </AvatarFallback>
              </Avatar>
            </div>
          </div>

          {activeView === "dashboard" && (
            <StudentDashboard studentData={mockStudentData} />
          )}

          {activeView === "progress" && (
            <div className="space-y-6">
              <TimeSeriesVisualization 
                data={mockTimeSeriesData}
                studentName={mockStudentData.name}
              />
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center space-x-2">
                      <Star className="h-5 w-5 text-yellow-600" />
                      <span>Achievement Progress</span>
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    {mockStudentData.achievements.map((achievement) => (
                      <div key={achievement.id} className="p-3 bg-muted/50 rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center space-x-2">
                            <span className="text-lg">{achievement.icon}</span>
                            <span className="font-medium text-sm">{achievement.title}</span>
                          </div>
                          <Badge variant={achievement.earned ? "default" : "secondary"}>
                            {achievement.points} pts
                          </Badge>
                        </div>
                        <p className="text-xs text-muted-foreground mb-2">
                          {achievement.description}
                        </p>
                        {!achievement.earned && achievement.progress && achievement.maxProgress && (
                          <div className="space-y-1">
                            <div className="flex justify-between text-xs">
                              <span>Progress</span>
                              <span>{achievement.progress} / {achievement.maxProgress}</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div 
                                className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                                style={{ width: `${(achievement.progress / achievement.maxProgress) * 100}%` }}
                              />
                            </div>
                          </div>
                        )}
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Weekly Goals</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-green-800">Maintain Attendance</span>
                        <Badge className="bg-green-100 text-green-800">Active</Badge>
                      </div>
                      <p className="text-sm text-green-700 mb-2">Keep your attendance above 90% this week</p>
                      <div className="w-full bg-green-200 rounded-full h-2">
                        <div className="bg-green-500 h-2 rounded-full" style={{ width: '92%' }}></div>
                      </div>
                      <div className="text-xs text-green-600 mt-1">92% - Great job!</div>
                    </div>
                    
                    <div className="p-4 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200 rounded-lg">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-blue-800">Assignment Excellence</span>
                        <Badge className="bg-blue-100 text-blue-800">In Progress</Badge>
                      </div>
                      <p className="text-sm text-blue-700 mb-2">Submit all assignments on time</p>
                      <div className="w-full bg-blue-200 rounded-full h-2">
                        <div className="bg-blue-500 h-2 rounded-full" style={{ width: '75%' }}></div>
                      </div>
                      <div className="text-xs text-blue-600 mt-1">3 of 4 assignments completed</div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {activeView === "leaderboard" && (
            <Leaderboard 
              currentStudentId="ST2024001"
              leaderboardData={mockLeaderboardData}
            />
          )}

          {activeView === "challenges" && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <Card className="bg-gradient-to-br from-purple-50 to-purple-100 border-purple-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-purple-200 rounded-full">
                      <Target className="h-6 w-6 text-purple-600" />
                    </div>
                    <Badge className="bg-purple-100 text-purple-800">50 Points</Badge>
                  </div>
                  <h3 className="font-semibold text-purple-800 mb-2">Perfect Week Challenge</h3>
                  <p className="text-sm text-purple-700 mb-4">
                    Attend all classes and submit all assignments on time for one week.
                  </p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>4/5 days</span>
                    </div>
                    <div className="w-full bg-purple-200 rounded-full h-2">
                      <div className="bg-purple-600 h-2 rounded-full" style={{ width: '80%' }}></div>
                    </div>
                  </div>
                  <Button className="w-full mt-4 bg-purple-600 hover:bg-purple-700">
                    Continue Challenge
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-orange-50 to-orange-100 border-orange-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-orange-200 rounded-full">
                      <BookOpen className="h-6 w-6 text-orange-600" />
                    </div>
                    <Badge className="bg-orange-100 text-orange-800">75 Points</Badge>
                  </div>
                  <h3 className="font-semibold text-orange-800 mb-2">Study Group Leader</h3>
                  <p className="text-sm text-orange-700 mb-4">
                    Participate in 5 study group sessions and help other students.
                  </p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Progress</span>
                      <span>2/5 sessions</span>
                    </div>
                    <div className="w-full bg-orange-200 rounded-full h-2">
                      <div className="bg-orange-600 h-2 rounded-full" style={{ width: '40%' }}></div>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full mt-4 border-orange-600 text-orange-600 hover:bg-orange-50">
                    Join Study Group
                  </Button>
                </CardContent>
              </Card>

              <Card className="bg-gradient-to-br from-green-50 to-green-100 border-green-200">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between mb-4">
                    <div className="p-3 bg-green-200 rounded-full">
                      <Star className="h-6 w-6 text-green-600" />
                    </div>
                    <Badge className="bg-green-100 text-green-800">100 Points</Badge>
                  </div>
                  <h3 className="font-semibold text-green-800 mb-2">Grade Improvement</h3>
                  <p className="text-sm text-green-700 mb-4">
                    Improve your overall GPA by 0.3 points this semester.
                  </p>
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Current GPA</span>
                      <span>3.6 / 4.0</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Target GPA</span>
                      <span>3.9 / 4.0</span>
                    </div>
                  </div>
                  <Button variant="outline" className="w-full mt-4 border-green-600 text-green-600 hover:bg-green-50">
                    View Study Tips
                  </Button>
                </CardContent>
              </Card>
            </div>
          )}

          {activeView === "rewards" && (
            <div className="space-y-6">
              <Card className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h2 className="text-2xl font-bold mb-2">Reward Shop</h2>
                      <p className="text-yellow-100">Exchange your points for amazing rewards!</p>
                    </div>
                    <div className="text-right">
                      <div className="text-3xl font-bold">{mockStudentData.stats.totalPoints}</div>
                      <div className="text-yellow-100">Available Points</div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <Card>
                  <CardContent className="p-6 text-center">
                    <div className="text-4xl mb-4">🎧</div>
                    <h3 className="font-semibold mb-2">Wireless Headphones</h3>
                    <p className="text-sm text-muted-foreground mb-4">Premium wireless headphones for studying</p>
                    <Badge variant="secondary" className="mb-4">2500 Points</Badge>
                    <Button className="w-full">Redeem</Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 text-center">
                    <div className="text-4xl mb-4">📚</div>
                    <h3 className="font-semibold mb-2">Study Guide Bundle</h3>
                    <p className="text-sm text-muted-foreground mb-4">Complete study guides for all subjects</p>
                    <Badge variant="secondary" className="mb-4">500 Points</Badge>
                    <Button className="w-full">Redeem</Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 text-center">
                    <div className="text-4xl mb-4">🍕</div>
                    <h3 className="font-semibold mb-2">Lunch Voucher</h3>
                    <p className="text-sm text-muted-foreground mb-4">Free lunch at the school cafeteria</p>
                    <Badge variant="secondary" className="mb-4">100 Points</Badge>
                    <Button className="w-full">Redeem</Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 text-center">
                    <div className="text-4xl mb-4">🎮</div>
                    <h3 className="font-semibold mb-2">Game Night Pass</h3>
                    <p className="text-sm text-muted-foreground mb-4">Skip one assignment (with teacher approval)</p>
                    <Badge variant="secondary" className="mb-4">1000 Points</Badge>
                    <Button variant="outline" className="w-full">Not Enough Points</Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 text-center">
                    <div className="text-4xl mb-4">🏆</div>
                    <h3 className="font-semibold mb-2">Achievement Badge</h3>
                    <p className="text-sm text-muted-foreground mb-4">Custom achievement badge for your profile</p>
                    <Badge variant="secondary" className="mb-4">200 Points</Badge>
                    <Button className="w-full">Redeem</Button>
                  </CardContent>
                </Card>

                <Card>
                  <CardContent className="p-6 text-center">
                    <div className="text-4xl mb-4">🎨</div>
                    <h3 className="font-semibold mb-2">Art Supplies Kit</h3>
                    <p className="text-sm text-muted-foreground mb-4">Professional art supplies for creative projects</p>
                    <Badge variant="secondary" className="mb-4">800 Points</Badge>
                    <Button className="w-full">Redeem</Button>
                  </CardContent>
                </Card>
              </div>
            </div>
          )}

          {activeView === "counselor" && (
            <AICounselorChat 
              studentName={mockStudentData.name}
              studentRiskLevel={mockStudentData.stats.riskLevel}
            />
          )}

          {activeView === "calendar" && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center space-x-2">
                  <Calendar className="h-5 w-5" />
                  <span>Academic Calendar</span>
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12 text-muted-foreground">
                  <Calendar className="h-12 w-12 mx-auto mb-4 opacity-50" />
                  <p>Calendar view would be implemented here with upcoming assignments, exams, and events.</p>
                </div>
              </CardContent>
            </Card>
          )}

          {activeView === "profile" && (
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Profile Settings</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center space-x-4">
                      <Avatar className="h-16 w-16">
                        <AvatarImage src={mockStudentData.avatar} />
                        <AvatarFallback className="bg-gradient-to-br from-blue-500 to-purple-600 text-white text-lg">
                          AT
                        </AvatarFallback>
                      </Avatar>
                      <div>
                        <h3 className="font-semibold">{mockStudentData.name}</h3>
                        <p className="text-sm text-muted-foreground">Student ID: {mockStudentData.id}</p>
                        <Button variant="outline" size="sm" className="mt-2">
                          Change Avatar
                        </Button>
                      </div>
                    </div>
                    <div className="space-y-3">
                      <div>
                        <label className="text-sm font-medium">Display Name</label>
                        <div className="mt-1">
                          <input
                            type="text"
                            className="w-full px-3 py-2 border border-gray-300 rounded-md"
                            defaultValue={mockStudentData.name}
                          />
                        </div>
                      </div>
                      <div>
                        <label className="text-sm font-medium">Notification Preferences</label>
                        <div className="mt-2 space-y-2">
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="email-notif" defaultChecked />
                            <label htmlFor="email-notif" className="text-sm">Email notifications</label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="achievement-notif" defaultChecked />
                            <label htmlFor="achievement-notif" className="text-sm">Achievement alerts</label>
                          </div>
                          <div className="flex items-center space-x-2">
                            <input type="checkbox" id="reminder-notif" defaultChecked />
                            <label htmlFor="reminder-notif" className="text-sm">Assignment reminders</label>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle>Statistics Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="text-center p-4 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">{mockStudentData.stats.level}</div>
                      <div className="text-sm text-blue-600">Current Level</div>
                    </div>
                    <div className="text-center p-4 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{mockStudentData.stats.totalPoints}</div>
                      <div className="text-sm text-green-600">Total Points</div>
                    </div>
                    <div className="text-center p-4 bg-orange-50 rounded-lg">
                      <div className="text-2xl font-bold text-orange-600">{mockStudentData.achievements.filter(a => a.earned).length}</div>
                      <div className="text-sm text-orange-600">Achievements</div>
                    </div>
                    <div className="text-center p-4 bg-purple-50 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">{mockStudentData.stats.currentStreak}</div>
                      <div className="text-sm text-purple-600">Day Streak</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          )}
        </main>
      </div>
    </SidebarProvider>
  );
}