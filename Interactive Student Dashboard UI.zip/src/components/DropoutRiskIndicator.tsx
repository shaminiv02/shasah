import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Progress } from "./ui/progress";
import { Badge } from "./ui/badge";
import { AlertTriangle, TrendingUp, TrendingDown, Minus } from "lucide-react";

interface RiskFactor {
  name: string;
  value: number;
  impact: 'positive' | 'negative' | 'neutral';
  description: string;
}

interface Student {
  id: string;
  name: string;
  riskScore: number;
  riskLevel: 'Low' | 'Medium' | 'High' | 'Critical';
  riskFactors: RiskFactor[];
  previousRiskScore?: number;
}

interface DropoutRiskIndicatorProps {
  student: Student;
}

export function DropoutRiskIndicator({ student }: DropoutRiskIndicatorProps) {
  const getRiskColor = (score: number) => {
    if (score <= 30) return 'text-green-600';
    if (score <= 60) return 'text-yellow-600';
    if (score <= 80) return 'text-orange-600';
    return 'text-red-600';
  };

  const getRiskBgColor = (score: number) => {
    if (score <= 30) return 'bg-green-50 border-green-200';
    if (score <= 60) return 'bg-yellow-50 border-yellow-200';
    if (score <= 80) return 'bg-orange-50 border-orange-200';
    return 'bg-red-50 border-red-200';
  };

  const getRiskProgressColor = (score: number) => {
    if (score <= 30) return 'bg-green-500';
    if (score <= 60) return 'bg-yellow-500';
    if (score <= 80) return 'bg-orange-500';
    return 'bg-red-500';
  };

  const getTrendIcon = () => {
    if (!student.previousRiskScore) return <Minus className="h-4 w-4 text-gray-500" />;
    
    if (student.riskScore > student.previousRiskScore) {
      return <TrendingUp className="h-4 w-4 text-red-500" />;
    } else if (student.riskScore < student.previousRiskScore) {
      return <TrendingDown className="h-4 w-4 text-green-500" />;
    }
    return <Minus className="h-4 w-4 text-gray-500" />;
  };

  const getImpactIcon = (impact: string) => {
    switch (impact) {
      case 'positive': return <TrendingDown className="h-4 w-4 text-green-500" />;
      case 'negative': return <TrendingUp className="h-4 w-4 text-red-500" />;
      default: return <Minus className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <AlertTriangle className="h-5 w-5" />
          <span>Dropout Risk Assessment</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Main Risk Score */}
        <div className={`p-6 rounded-lg border-2 ${getRiskBgColor(student.riskScore)}`}>
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-lg font-semibold">{student.name}</h3>
              <p className="text-sm text-muted-foreground">Student ID: {student.id}</p>
            </div>
            <div className="flex items-center space-x-2">
              {getTrendIcon()}
              <Badge variant="outline" className={getRiskColor(student.riskScore)}>
                {student.riskLevel}
              </Badge>
            </div>
          </div>
          
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm">Dropout Risk Score</span>
              <span className={`text-2xl font-bold ${getRiskColor(student.riskScore)}`}>
                {student.riskScore}%
              </span>
            </div>
            <div className="relative">
              <Progress value={student.riskScore} className="h-3" />
              <div 
                className={`absolute top-0 left-0 h-3 rounded-full transition-all ${getRiskProgressColor(student.riskScore)}`}
                style={{ width: `${student.riskScore}%` }}
              />
            </div>
            <div className="flex justify-between text-xs text-muted-foreground">
              <span>Low Risk</span>
              <span>High Risk</span>
            </div>
          </div>

          {student.previousRiskScore && (
            <div className="mt-4 pt-4 border-t">
              <div className="flex items-center justify-between text-sm">
                <span>Previous Score:</span>
                <span>{student.previousRiskScore}%</span>
              </div>
              <div className="flex items-center justify-between text-sm">
                <span>Change:</span>
                <span className={
                  student.riskScore > student.previousRiskScore 
                    ? 'text-red-600' 
                    : student.riskScore < student.previousRiskScore 
                    ? 'text-green-600' 
                    : 'text-gray-600'
                }>
                  {student.riskScore > student.previousRiskScore ? '+' : ''}
                  {student.riskScore - student.previousRiskScore}%
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Risk Factors */}
        <div className="space-y-4">
          <h4 className="font-medium">Contributing Risk Factors</h4>
          <div className="space-y-3">
            {student.riskFactors.map((factor, index) => (
              <div key={index} className="p-3 bg-muted/50 rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    {getImpactIcon(factor.impact)}
                    <span className="font-medium text-sm">{factor.name}</span>
                  </div>
                  <span className="text-sm font-semibold">{factor.value}%</span>
                </div>
                <Progress value={Math.abs(factor.value)} className="h-2 mb-2" />
                <p className="text-xs text-muted-foreground">{factor.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Recommendations */}
        <div className="space-y-2">
          <h4 className="font-medium">Recommended Actions</h4>
          <div className="space-y-2">
            {student.riskScore >= 80 && (
              <div className="p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-sm text-red-800">
                  <strong>Immediate intervention required:</strong> Schedule one-on-one counseling session within 48 hours.
                </p>
              </div>
            )}
            {student.riskScore >= 60 && student.riskScore < 80 && (
              <div className="p-3 bg-orange-50 border border-orange-200 rounded-lg">
                <p className="text-sm text-orange-800">
                  <strong>Close monitoring needed:</strong> Increase check-ins and provide additional academic support.
                </p>
              </div>
            )}
            {student.riskScore >= 30 && student.riskScore < 60 && (
              <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p className="text-sm text-yellow-800">
                  <strong>Preventive measures:</strong> Consider peer tutoring and engagement activities.
                </p>
              </div>
            )}
            {student.riskScore < 30 && (
              <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                <p className="text-sm text-green-800">
                  <strong>Maintain current support:</strong> Continue regular monitoring and positive reinforcement.
                </p>
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}