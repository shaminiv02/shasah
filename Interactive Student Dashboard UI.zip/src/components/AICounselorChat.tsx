import { useState, useRef, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "./ui/card";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Avatar, AvatarFallback, AvatarImage } from "./ui/avatar";
import { ScrollArea } from "./ui/scroll-area";
import { Badge } from "./ui/badge";
import { 
  MessageCircle, 
  Send, 
  Bot, 
  User, 
  Heart, 
  Lightbulb, 
  Target, 
  Book,
  Calendar,
  Smile
} from "lucide-react";

interface ChatMessage {
  id: string;
  type: 'user' | 'ai';
  content: string;
  timestamp: string;
  suggestions?: string[];
  resources?: Array<{
    title: string;
    type: 'article' | 'video' | 'exercise';
    url: string;
  }>;
  sentiment?: 'positive' | 'neutral' | 'concerned';
}

interface AICounselorChatProps {
  studentName: string;
  studentRiskLevel: 'Low' | 'Medium' | 'High';
}

export function AICounselorChat({ studentName, studentRiskLevel }: AICounselorChatProps) {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      type: 'ai',
      content: `Hi ${studentName}! I'm your AI counselor, here to support you on your academic journey. How are you feeling about school today?`,
      timestamp: new Date().toISOString(),
      suggestions: [
        "I'm doing great!",
        "I'm feeling stressed about exams",
        "I need help with time management",
        "I want to improve my grades"
      ]
    }
  ]);
  
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const scrollAreaRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    if (scrollAreaRef.current) {
      const scrollContainer = scrollAreaRef.current.querySelector('[data-radix-scroll-area-viewport]');
      if (scrollContainer) {
        scrollContainer.scrollTop = scrollContainer.scrollHeight;
      }
    }
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const generateAIResponse = (userMessage: string): ChatMessage => {
    // Mock AI responses based on common student concerns
    let response = "";
    let suggestions: string[] = [];
    let resources: Array<{title: string; type: 'article' | 'video' | 'exercise'; url: string}> = [];
    let sentiment: 'positive' | 'neutral' | 'concerned' = 'neutral';

    if (userMessage.toLowerCase().includes('stress') || userMessage.toLowerCase().includes('anxious')) {
      response = "I understand you're feeling stressed. That's completely normal, and it shows you care about your studies. Let's work together to find some strategies that can help you manage this stress effectively.";
      suggestions = [
        "What specific things are stressing you out?",
        "Can you teach me breathing exercises?",
        "How can I organize my study schedule?"
      ];
      resources = [
        { title: "5-Minute Stress Relief Techniques", type: "video", url: "#" },
        { title: "Building Resilience in Students", type: "article", url: "#" }
      ];
      sentiment = 'concerned';
    } else if (userMessage.toLowerCase().includes('grade') || userMessage.toLowerCase().includes('failing')) {
      response = "I hear your concern about grades. Remember, grades don't define your worth - they're just feedback to help you learn and grow. Let's identify specific areas where you'd like to improve and create a plan together.";
      suggestions = [
        "Which subject is most challenging?",
        "How can I study more effectively?",
        "I want to talk to my teacher"
      ];
      resources = [
        { title: "Effective Study Strategies", type: "article", url: "#" },
        { title: "Time Management for Students", type: "exercise", url: "#" }
      ];
    } else if (userMessage.toLowerCase().includes('great') || userMessage.toLowerCase().includes('good')) {
      response = "That's wonderful to hear! I'm so glad you're feeling positive about school. Keep up that great energy! Is there anything specific that's going particularly well that you'd like to share?";
      suggestions = [
        "I aced my last test!",
        "I made a new friend",
        "My teacher complimented my work"
      ];
      sentiment = 'positive';
    } else if (userMessage.toLowerCase().includes('time') || userMessage.toLowerCase().includes('manage')) {
      response = "Time management is such an important skill, and you're smart to work on it! Effective time management can reduce stress and improve your academic performance. Let me share some techniques that work well for students.";
      suggestions = [
        "Show me a daily schedule template",
        "How do I prioritize tasks?",
        "What about study breaks?"
      ];
      resources = [
        { title: "The Pomodoro Technique for Students", type: "video", url: "#" },
        { title: "Daily Planning Worksheet", type: "exercise", url: "#" }
      ];
    } else {
      response = "Thank you for sharing that with me. I'm here to listen and help however I can. Remember, every challenge is an opportunity to grow stronger and more resilient.";
      suggestions = [
        "I need study tips",
        "I'm worried about my future",
        "Can you help me set goals?"
      ];
    }

    return {
      id: Date.now().toString(),
      type: 'ai',
      content: response,
      timestamp: new Date().toISOString(),
      suggestions,
      resources,
      sentiment
    };
  };

  const handleSendMessage = (messageText?: string) => {
    const message = messageText || inputMessage.trim();
    if (!message) return;

    // Add user message
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      type: 'user',
      content: message,
      timestamp: new Date().toISOString()
    };

    setMessages(prev => [...prev, userMessage]);
    setInputMessage('');
    setIsTyping(true);

    // Simulate AI thinking time
    setTimeout(() => {
      const aiResponse = generateAIResponse(message);
      setMessages(prev => [...prev, aiResponse]);
      setIsTyping(false);
    }, 1500);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const getSentimentIcon = (sentiment?: string) => {
    switch (sentiment) {
      case 'positive': return <Heart className="h-4 w-4 text-green-600" />;
      case 'concerned': return <Target className="h-4 w-4 text-yellow-600" />;
      default: return <Lightbulb className="h-4 w-4 text-blue-600" />;
    }
  };

  const formatTime = (timestamp: string) => {
    return new Date(timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
  };

  return (
    <Card className="h-[600px] flex flex-col">
      <CardHeader className="pb-3">
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div className="p-2 bg-blue-100 rounded-full">
              <Bot className="h-5 w-5 text-blue-600" />
            </div>
            <div>
              <span>AI Counselor</span>
              <div className="text-sm font-normal text-muted-foreground">
                Always here to help • {studentRiskLevel} risk student
              </div>
            </div>
          </div>
          <Badge 
            variant="outline" 
            className="bg-green-50 text-green-700 border-green-200"
          >
            <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
            Online
          </Badge>
        </CardTitle>
      </CardHeader>

      <CardContent className="flex-1 flex flex-col p-0">
        <ScrollArea ref={scrollAreaRef} className="flex-1 px-6">
          <div className="space-y-4 pb-4">
            {messages.map((message) => (
              <div key={message.id} className="space-y-3">
                <div className={`flex gap-3 ${message.type === 'user' ? 'justify-end' : 'justify-start'}`}>
                  {message.type === 'ai' && (
                    <Avatar className="h-8 w-8 bg-blue-100">
                      <AvatarFallback>
                        <Bot className="h-4 w-4 text-blue-600" />
                      </AvatarFallback>
                    </Avatar>
                  )}
                  
                  <div className={`max-w-[80%] space-y-1 ${message.type === 'user' ? 'order-first' : ''}`}>
                    <div className={`rounded-lg p-3 ${
                      message.type === 'user' 
                        ? 'bg-blue-500 text-white ml-auto' 
                        : 'bg-muted'
                    }`}>
                      <p className="text-sm">{message.content}</p>
                    </div>
                    <div className={`text-xs text-muted-foreground flex items-center gap-1 ${
                      message.type === 'user' ? 'justify-end' : 'justify-start'
                    }`}>
                      {message.sentiment && getSentimentIcon(message.sentiment)}
                      {formatTime(message.timestamp)}
                    </div>
                  </div>

                  {message.type === 'user' && (
                    <Avatar className="h-8 w-8 bg-purple-100">
                      <AvatarFallback>
                        <User className="h-4 w-4 text-purple-600" />
                      </AvatarFallback>
                    </Avatar>
                  )}
                </div>

                {/* Quick Suggestions */}
                {message.type === 'ai' && message.suggestions && (
                  <div className="ml-11 space-y-2">
                    <div className="text-xs text-muted-foreground">Quick responses:</div>
                    <div className="flex flex-wrap gap-2">
                      {message.suggestions.map((suggestion, index) => (
                        <Button
                          key={index}
                          variant="outline"
                          size="sm"
                          className="text-xs h-7"
                          onClick={() => handleSendMessage(suggestion)}
                        >
                          {suggestion}
                        </Button>
                      ))}
                    </div>
                  </div>
                )}

                {/* Resources */}
                {message.type === 'ai' && message.resources && message.resources.length > 0 && (
                  <div className="ml-11 space-y-2">
                    <div className="text-xs text-muted-foreground">Helpful resources:</div>
                    <div className="space-y-1">
                      {message.resources.map((resource, index) => (
                        <div key={index} className="flex items-center space-x-2 p-2 bg-blue-50 rounded-lg">
                          {resource.type === 'article' && <Book className="h-4 w-4 text-blue-600" />}
                          {resource.type === 'video' && <MessageCircle className="h-4 w-4 text-red-600" />}
                          {resource.type === 'exercise' && <Target className="h-4 w-4 text-green-600" />}
                          <span className="text-xs text-blue-800 cursor-pointer hover:underline">
                            {resource.title}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ))}

            {/* Typing Indicator */}
            {isTyping && (
              <div className="flex gap-3">
                <Avatar className="h-8 w-8 bg-blue-100">
                  <AvatarFallback>
                    <Bot className="h-4 w-4 text-blue-600" />
                  </AvatarFallback>
                </Avatar>
                <div className="bg-muted rounded-lg p-3">
                  <div className="flex space-x-1">
                    <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce"></div>
                    <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                    <div className="w-2 h-2 bg-muted-foreground rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>

        {/* Input Area */}
        <div className="p-4 border-t">
          <div className="flex space-x-2">
            <Input
              placeholder="Type your message..."
              value={inputMessage}
              onChange={(e) => setInputMessage(e.target.value)}
              onKeyPress={handleKeyPress}
              className="flex-1"
            />
            <Button 
              onClick={() => handleSendMessage()}
              disabled={!inputMessage.trim()}
              className="bg-blue-500 hover:bg-blue-600"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
          <div className="text-xs text-muted-foreground mt-2">
            Press Enter to send • This AI counselor provides emotional support and study guidance
          </div>
        </div>
      </CardContent>
    </Card>
  );
}